// clinic-system.js - خادم نظام العيادات
const express = require('express');
const app = express();
const PORT = 3000;

console.log('🚀 جاري تشغيل نظام إدارة العيادات...');

// صفحة الترحيب
app.get('/', (req, res) => {
    res.send(`
        <!DOCTYPE html>
        <html dir="rtl">
        <head>
            <meta charset="UTF-8">
            <title>نظام العيادات clinic management </title>
            <style>
                body {
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    min-height: 100vh;
                    margin: 0;
                    padding: 0;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                }
                .container {
                    background: rgba(255, 255, 255, 0.95);
                    color: #333;
                    padding: 40px;
                    border-radius: 20px;
                    box-shadow: 0 20px 60px rgba(0,0,0,0.3);
                    text-align: center;
                    max-width: 600px;
                }
                h1 {
                    color: #2563eb;
                    margin-bottom: 20px;
                }
                .status {
                    background: #10b981;
                    color: white;
                    padding: 15px;
                    border-radius: 10px;
                    margin: 20px 0;
                    font-size: 1.2em;
                }
                .links {
                    margin-top: 30px;
                }
                a {
                    display: inline-block;
                    background: #2563eb;
                    color: white;
                    padding: 12px 24px;
                    margin: 10px;
                    border-radius: 8px;
                    text-decoration: none;
                    font-weight: bold;
                    transition: all 0.3s;
                }
                a:hover {
                    background: #1d4ed8;
                    transform: translateY(-2px);
                }
                .info {
                    background: #f8fafc;
                    padding: 15px;
                    border-radius: 10px;
                    margin-top: 20px;
                    text-align: right;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>🏥 نظام إدارة العيادات clinic management </h1>
                <p>نظام متكامل لإدارة العيادات الطبية</p>
                
                <div class="status">
                    ✅ النظام يعمل بنجاح على المنفذ ${PORT}
                </div>
                
                <div class="info">
                    <p><strong>الوقت:</strong> ${new Date().toLocaleString('ar-SA')}</p>
                    <p><strong>الإصدار:</strong> 1.0.0</p>
                    <p><strong>الحالة:</strong> جاهز للعمل</p>
                </div>
                
                <div class="links">
                    <a href="/api/health">فحص حالة النظام</a>
                    <a href="/api/test">اختبار واجهة API</a>
                    <a href="http://localhost:${PORT}/api/health" target="_blank">فتح في نافذة جديدة</a>
                </div>
                
                <p style="margin-top: 30px; color: #666;">
                    نظام إدارة شامل للعيادات - clinic management  Clinic Management System
                </p>
            </div>
        </body>
        </html>
    `);
});

// واجهة API للصحة
app.get('/api/health', (req, res) => {
    res.json({
        status: 'OK',
        message: '✅ نظام إدارة العيادات clinic management  يعمل بنجاح',
        timestamp: new Date().toISOString(),
        version: '1.0.0',
        server: 'Node.js + Express',
        port: PORT,
        database: 'ready to connect'
    });
});

// واجهة API تجريبية
app.get('/api/test', (req, res) => {
    res.json({
        success: true,
        data: {
            patients: 3,
            doctors: 2,
            clinics: 2,
            appointments: 5
        },
        message: 'واجهة API تعمل بشكل صحيح'
    });
});

// بدء الخادم
app.listen(PORT, () => {
    console.log('='.repeat(50));
    console.log('🚀 نظام إدارة العيادات clinic management ');
    console.log('='.repeat(50));
    console.log(`📡 الخادم يعمل على: http://localhost:${PORT}`);
    console.log(`🔗 روابط الاختبار:`);
    console.log(`   📍 http://localhost:${PORT}/`);
    console.log(`   📍 http://localhost:${PORT}/api/health`);
    console.log(`   📍 http://localhost:${PORT}/api/test`);
    console.log('='.repeat(50));
    console.log('📌 اضغط Ctrl+C لإيقاف الخادم');
    console.log('='.repeat(50));
});