// clinic-auto.js - خادم يعيد التشغيل تلقائياً
const express = require('express');
const app = express();
const PORT = 3000;

console.log('🚀 جاري تشغيل نظام إدارة العيادات clinic management ...\n');

// Middleware
app.use(express.json());

// بيانات تجريبية كاملة
const mockData = {
    patients: [
        { id: 1, code: 'P-1001', name: 'أحمد محمد', phone: '01012345678', birth: '1979-05-15' },
        { id: 2, code: 'P-1002', name: 'سارة خالد', phone: '01087654321', birth: '1996-08-22' },
        { id: 3, code: 'P-1003', name: 'معتز علي', phone: '01055556666', birth: '1962-03-10' }
    ],
    doctors: [
        { id: 1, name: 'د. محمود عبدالرحمن', specialty: 'طب عام', license: 'MED-001', fee: 150 },
        { id: 2, name: 'د. نادية فاروق', specialty: 'أطفال', license: 'MED-002', fee: 180 },
        { id: 3, name: 'د. هبة أحمد', specialty: 'قلب', license: 'MED-003', fee: 250 }
    ],
    clinics: [
        { id: 1, name: 'العيادة العامة', floor: 'الأول', room: '101', hours: '9 ص - 5 م' },
        { id: 2, name: 'عيادة الأطفال', floor: 'الثاني', room: '201', hours: '10 ص - 6 م' },
        { id: 3, name: 'عيادة القلب', floor: 'الثالث', room: '301', hours: '8 ص - 2 م' }
    ],
    appointments: [
        { id: 1, code: 'APT-2024-001', patient: 'أحمد محمد', doctor: 'د. محمود عبدالرحمن', date: '2024-12-20', time: '10:00 ص' },
        { id: 2, code: 'APT-2024-002', patient: 'سارة خالد', doctor: 'د. نادية فاروق', date: '2024-12-21', time: '11:30 ص' }
    ]
};

// ==================== واجهات API ====================

app.get('/api/health', (req, res) => {
    res.json({
        status: 'OK',
        message: '✅ نظام إدارة العيادات clinic management  يعمل بنجاح',
        timestamp: new Date().toISOString(),
        version: '2.0.0',
        endpoints: {
            health: '/api/health',
            patients: '/api/patients',
            doctors: '/api/doctors',
            clinics: '/api/clinics',
            appointments: '/api/appointments',
            stats: '/api/dashboard/stats'
        }
    });
});

app.get('/api/patients', (req, res) => {
    res.json(mockData.patients);
});

app.get('/api/doctors', (req, res) => {
    res.json(mockData.doctors);
});

app.get('/api/clinics', (req, res) => {
    res.json(mockData.clinics);
});

app.get('/api/appointments', (req, res) => {
    res.json(mockData.appointments);
});

app.get('/api/dashboard/stats', (req, res) => {
    res.json({
        totalPatients: mockData.patients.length,
        totalDoctors: mockData.doctors.length,
        totalClinics: mockData.clinics.length,
        totalAppointments: mockData.appointments.length,
        todayAppointments: 5,
        monthlyRevenue: 18500,
        occupancyRate: '86%'
    });
});

// ==================== الصفحة الرئيسية ====================

app.get('/', (req, res) => {
    res.send(`
        <!DOCTYPE html>
        <html dir="rtl">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>نظام إدارة العيادات clinic management </title>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body {
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: #333;
                    min-height: 100vh;
                }
                .container {
                    max-width: 1200px;
                    margin: 0 auto;
                    padding: 20px;
                }
                header {
                    background: white;
                    padding: 30px;
                    border-radius: 20px;
                    margin-bottom: 30px;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
                    text-align: center;
                }
                header h1 {
                    color: #2563eb;
                    margin-bottom: 10px;
                    font-size: 2.5rem;
                }
                .dashboard {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                    gap: 20px;
                    margin-bottom: 30px;
                }
                .card {
                    background: white;
                    padding: 25px;
                    border-radius: 15px;
                    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
                    transition: transform 0.3s;
                }
                .card:hover {
                    transform: translateY(-5px);
                }
                .card h3 {
                    color: #2563eb;
                    margin-bottom: 15px;
                    display: flex;
                    align-items: center;
                    gap: 10px;
                }
                .card .count {
                    font-size: 2.5rem;
                    font-weight: bold;
                    color: #1f2937;
                }
                .api-section {
                    background: white;
                    padding: 30px;
                    border-radius: 15px;
                    margin: 30px 0;
                }
                .api-links {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                    gap: 15px;
                    margin-top: 20px;
                }
                .api-link {
                    padding: 15px;
                    background: #f8fafc;
                    border-radius: 10px;
                    border-left: 4px solid #2563eb;
                }
                .api-link a {
                    color: #2563eb;
                    text-decoration: none;
                    font-weight: 500;
                }
                .api-link a:hover {
                    text-decoration: underline;
                }
                .method {
                    display: inline-block;
                    padding: 3px 10px;
                    background: #dbeafe;
                    color: #1d4ed8;
                    border-radius: 4px;
                    font-size: 0.9rem;
                    margin-left: 10px;
                }
                .status {
                    padding: 10px 20px;
                    background: #10b981;
                    color: white;
                    border-radius: 20px;
                    display: inline-block;
                    margin: 10px 0;
                }
                footer {
                    text-align: center;
                    margin-top: 50px;
                    padding: 20px;
                    color: white;
                }
            </style>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        </head>
        <body>
            <div class="container">
                <header>
                    <h1><i class="fas fa-hospital-alt"></i> نظام إدارة العيادات clinic management </h1>
                    <p>نظام متكامل لإدارة العيادات الطبية - الإصدار 2.0.0</p>
                    <div class="status">
                        <i class="fas fa-check-circle"></i> النظام يعمل على المنفذ ${PORT}
                    </div>
                </header>
                
                <div class="dashboard">
                    <div class="card">
                        <h3><i class="fas fa-user-injured"></i> المرضى</h3>
                        <div class="count">${mockData.patients.length}</div>
                        <p>إجمالي المرضى المسجلين</p>
                    </div>
                    <div class="card">
                        <h3><i class="fas fa-user-md"></i> الأطباء</h3>
                        <div class="count">${mockData.doctors.length}</div>
                        <p>الأطباء العاملين</p>
                    </div>
                    <div class="card">
                        <h3><i class="fas fa-clinic-medical"></i> العيادات</h3>
                        <div class="count">${mockData.clinics.length}</div>
                        <p>عدد العيادات النشطة</p>
                    </div>
                    <div class="card">
                        <h3><i class="fas fa-calendar-check"></i> الحجوزات</h3>
                        <div class="count">${mockData.appointments.length}</div>
                        <p>إجمالي الحجوزات</p>
                    </div>
                </div>
                
                <div class="api-section">
                    <h2><i class="fas fa-code"></i> واجهات برمجة التطبيقات (API)</h2>
                    <div class="api-links">
                        <div class="api-link">
                            <span class="method">GET</span>
                            <a href="/api/health" target="_blank">/api/health</a>
                            <p>فحص حالة النظام</p>
                        </div>
                        <div class="api-link">
                            <span class="method">GET</span>
                            <a href="/api/patients" target="_blank">/api/patients</a>
                            <p>عرض قائمة المرضى</p>
                        </div>
                        <div class="api-link">
                            <span class="method">GET</span>
                            <a href="/api/doctors" target="_blank">/api/doctors</a>
                            <p>عرض قائمة الأطباء</p>
                        </div>
                        <div class="api-link">
                            <span class="method">GET</span>
                            <a href="/api/clinics" target="_blank">/api/clinics</a>
                            <p>عرض قائمة العيادات</p>
                        </div>
                        <div class="api-link">
                            <span class="method">GET</span>
                            <a href="/api/appointments" target="_blank">/api/appointments</a>
                            <p>عرض الحجوزات</p>
                        </div>
                        <div class="api-link">
                            <span class="method">GET</span>
                            <a href="/api/dashboard/stats" target="_blank">/api/dashboard/stats</a>
                            <p>إحصائيات النظام</p>
                        </div>
                    </div>
                </div>
                
                <div class="api-section">
                    <h2><i class="fas fa-rocket"></i> معلومات النظام</h2>
                    <p><strong>المنفذ:</strong> ${PORT}</p>
                    <p><strong>الإصدار:</strong> 2.0.0</p>
                    <p><strong>الحالة:</strong> <span class="status">✅ يعمل بنجاح</span></p>
                    <p><strong>الوقت:</strong> ${new Date().toLocaleString('ar-SA')}</p>
                </div>
            </div>
            
            <footer>
                <p>© 2024 نظام إدارة العيادات clinic management . جميع الحقوق محفوظة.</p>
                <p>تم التطوير باستخدام Node.js + Express</p>
            </footer>
            
            <script>
                // تحديث الوقت كل دقيقة
                function updateTime() {
                    const timeElement = document.querySelector('.api-section:last-child p:last-child');
                    if (timeElement) {
                        timeElement.innerHTML = '<strong>الوقت:</strong> ' + new Date().toLocaleString('ar-SA');
                    }
                }
                setInterval(updateTime, 60000);
            </script>
        </body>
        </html>
    `);
});

// ==================== تشغيل الخادم ====================

app.listen(PORT, () => {
    console.log('='.repeat(60));
    console.log('🚀 نظام إدارة العيادات clinic management  - الإصدار 2.0.0');
    console.log('='.repeat(60));
    console.log(`📡 الخادم يعمل على: http://localhost:${PORT}`);
    console.log(`📊 قاعدة البيانات: بيانات تجريبية (${mockData.patients.length} مريض، ${mockData.doctors.length} طبيب)`);
    console.log('='.repeat(60));
    console.log('🔗 روابط الاختبار:');
    console.log(`   1. 📍 http://localhost:${PORT}/`);
    console.log(`   2. 📍 http://localhost:${PORT}/api/health`);
    console.log(`   3. 📍 http://localhost:${PORT}/api/patients`);
    console.log(`   4. 📍 http://localhost:${PORT}/api/doctors`);
    console.log(`   5. 📍 http://localhost:${PORT}/api/dashboard/stats`);
    console.log('='.repeat(60));
    console.log('📌 اضغط Ctrl+C لإيقاف الخادم');
    console.log('='.repeat(60));
});

// معالجة إيقاف الخادم بشكل أنيق
process.on('SIGINT', () => {
    console.log('\n\n🛑 جاري إيقاف الخادم...');
    console.log('👋 تم إيقاف نظام إدارة العيادات clinic management ');
    process.exit(0);
});