// ============================================
// ملف معالج الـ APIs - نظام مستشفى حازم الدولي
// ============================================

class APIHandler {
    constructor() {
        this.baseURL = window.location.origin;
    }

    // جلب بيانات الأطباء من قاعدة البيانات الحقيقية
    async getDoctors() {
        try {
            console.log('🔄 جلب بيانات الأطباء من قاعدة البيانات...');
            const response = await fetch(`${this.baseURL}/api/doctors`);
            
            if (!response.ok) {
                throw new Error(`خطأ في الخادم: ${response.status}`);
            }
            
            const result = await response.json();
            
            if (result.success === false) {
                throw new Error(result.error || 'خطأ في جلب البيانات');
            }
            
            console.log(`✅ تم جلب ${result.data ? result.data.length : result.length} طبيب من قاعدة البيانات`);
            return result.data || result;
        } catch (error) {
            console.error('❌ خطأ في جلب بيانات الأطباء:', error);
            throw error;
        }
    }

    // جلب إحصائيات النظام
    async getDashboardStats() {
        try {
            const response = await fetch(`${this.baseURL}/api/dashboard/stats`);
            if (!response.ok) throw new Error('خطأ في جلب الإحصائيات');
            return await response.json();
        } catch (error) {
            console.error('❌ خطأ في جلب الإحصائيات:', error);
            return {
                success: false,
                data: {
                    totalDoctors: 0,
                    totalPatients: 0,
                    totalAppointments: 0,
                    todayAppointments: 0,
                    activeClinics: 0,
                    pendingPayments: 0
                }
            };
        }
    }

    // البحث عن أطباء
    async searchDoctors(query) {
        try {
            const response = await fetch(`${this.baseURL}/api/search/doctors?q=${encodeURIComponent(query)}`);
            if (!response.ok) throw new Error('خطأ في البحث');
            const result = await response.json();
            return result.data || result;
        } catch (error) {
            console.error('❌ خطأ في البحث:', error);
            return [];
        }
    }

    // تحويل تنسيق البيانات من API إلى تنسيق الواجهة
    formatDoctorData(apiDoctor) {
        // تحديد التخصص بالعربية
        const specialtyMap = {
            'Family Medicine': 'طب عام',
            'Pediatrics': 'طب الأطفال',
            'Orthopedics': 'جراحة العظام',
            'Cardiology': 'أمراض القلب',
            'Surgery': 'جراحة عامة',
            'Dermatology': 'الجلدية',
            'general': 'طب عام',
            'pediatric': 'طب الأطفال',
            'ortho': 'جراحة العظام',
            'cardio': 'أمراض القلب',
            'surgery': 'جراحة عامة',
            'dermatology': 'الجلدية'
        };

        return {
            id: apiDoctor.doctor_id || apiDoctor.id,
            firstName: this.extractFirstName(apiDoctor.full_name),
            lastName: this.extractLastName(apiDoctor.full_name),
            fullName: apiDoctor.full_name ? `د. ${apiDoctor.full_name}` : 'د. غير محدد',
            specialty: specialtyMap[apiDoctor.specialization] || apiDoctor.specialization || 'غير محدد',
            specialtyValue: this.getSpecialtyValue(apiDoctor.specialization),
            clinic: apiDoctor.clinic_name || 'العيادة الرئيسية',
            phone: apiDoctor.phone || 'لا يوجد',
            email: apiDoctor.email || 'لا يوجد',
            qualifications: apiDoctor.qualifications || 'دكتوراه في الطب',
            rating: apiDoctor.rating || 4.5,
            patientsPerDay: apiDoctor.patients_per_day || 15,
            status: apiDoctor.is_available ? 'available' : 'off',
            schedule: {
                "الإثنين - الخميس": "9:00 ص - 5:00 م",
                "الجمعة": "10:00 ص - 2:00 م"
            },
            appointments: apiDoctor.appointments || 12,
            joinedDate: apiDoctor.created_at ? apiDoctor.created_at.split('T')[0] : '2024-01-01',
            licenseNumber: apiDoctor.license_number || 'غير متوفر'
        };
    }

    // استخراج الاسم الأول
    extractFirstName(fullName) {
        if (!fullName) return 'غير';
        const parts = fullName.split(' ');
        return parts[0] || 'غير';
    }

    // استخراج اسم العائلة
    extractLastName(fullName) {
        if (!fullName) return 'محدد';
        const parts = fullName.split(' ');
        return parts.slice(1).join(' ') || 'محدد';
    }

    getSpecialtyValue(specialization) {
        const specialtyMap = {
            'Family Medicine': 'general',
            'Pediatrics': 'pediatric',
            'Orthopedics': 'ortho',
            'Cardiology': 'cardio',
            'Surgery': 'surgery',
            'Dermatology': 'dermatology',
            'طب عام': 'general',
            'طب الأطفال': 'pediatric',
            'جراحة العظام': 'ortho',
            'أمراض القلب': 'cardio',
            'جراحة عامة': 'surgery',
            'الجلدية': 'dermatology'
        };
        
        return specialtyMap[specialization] || 'general';
    }
}

// إنشاء نسخة عامة للمعالج
window.API = new APIHandler();
console.log('✅ تم تحميل API Handler بنجاح');