// system-updater.js - تحديث قائمة الأطباء
function updateDoctorsInBookingForm() {
    const doctors = JSON.parse(localStorage.getItem('clinic management _doctors') || '[]');
    const doctorSelect = document.getElementById('doctorSelect');
    
    if (doctorSelect) {
        let options = '<option value="">اختر الطبيب</option>';
        doctors.forEach(doctor => {
            options += '<option value="' + doctor.id + '">' + doctor.fullName + ' - ' + doctor.specialty + '</option>';
        });
        doctorSelect.innerHTML = options;
    }
}

document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('doctorSelect')) {
        updateDoctorsInBookingForm();
    }
});

window.updateDoctorsInBookingForm = updateDoctorsInBookingForm;