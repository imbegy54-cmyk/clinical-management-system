/**
 * تحسين أداء صفحة التقارير - حل مشكلة Long Tasks و Forced Reflow
 */

class ReportPerformanceOptimizer {
    constructor() {
        this.isProcessing = false;
        this.initEventListeners();
    }

    /**
     * تهيئة معالجات الأحداث المحسنة
     */
    initEventListeners() {
        // استخدام event delegation بدلاً من معالجات متعددة
        document.addEventListener('click', this.handleClick.bind(this), { passive: true });
        
        // معالجات محددة للأزرار
        this.optimizeReportButtons();
    }

    /**
     * تحسين أزرار التقارير
     */
    optimizeReportButtons() {
        const reportButtons = document.querySelectorAll('[data-report-action]');
        
        reportButtons.forEach(button => {
            // إزالة المعالجات القديمة إذا وجدت
            button.replaceWith(button.cloneNode(true));
            
            // إضافة معالج جديد محسن
            button.addEventListener('click', async (e) => {
                e.preventDefault();
                e.stopPropagation();
                
                if (this.isProcessing) return;
                
                const action = button.dataset.reportAction;
                await this.handleReportAction(action, button);
            }, { passive: false });
        });
    }

    /**
     * معالجة إجراءات التقارير
     */
    async handleReportAction(action, button) {
        this.isProcessing = true;
        
        try {
            // إظهار حالة التحميل
            this.showLoadingState(button);
            
            // استخدام Web Worker للمهام الثقيلة إن أمكن
            if (this.shouldUseWorker(action)) {
                await this.processWithWorker(action);
            } else {
                // معالجة تدريجية للمهام الكبيرة
                await this.processInChunks(action);
            }
            
            // تحديث الواجهة بكفاءة
            await this.updateUIPerformant();
            
        } catch (error) {
            console.error('Report error:', error);
            this.showError(error);
        } finally {
            this.isProcessing = false;
            this.hideLoadingState(button);
        }
    }

    /**
     * المعالجة العامة للنقرات
     */
    async handleClick(event) {
        const target = event.target;
        
        // تحديد العناصر التي تحتاج معالجة خاصة
        if (target.closest('.data-grid-cell')) {
            await this.handleCellClick(target);
        } else if (target.closest('.sort-column')) {
            await this.handleSortClick(target);
        }
    }

    /**
     * معالجة نقرات الخلايا بكفاءة
     */
    async handleCellClick(cell) {
        // تجنب إعادة التنسيق القسري
        this.batchDOMUpdates(() => {
            // قراءة كل القياسات أولاً
            const measurements = {
                width: cell.offsetWidth,
                height: cell.offsetHeight,
                position: cell.getBoundingClientRect()
            };
            
            // إجراء التحديثات
            this.updateCellSelection(cell, measurements);
        });
    }

    /**
     * تجميع تحديثات DOM لتقليل إعادة التنسيق
     */
    batchDOMUpdates(callback) {
        // إجبار التصيير المتزامن أولاً
        document.body.classList.add('freeze-layout');
        
        // تنفيذ التحديثات داخل requestAnimationFrame
        requestAnimationFrame(() => {
            // قراءة جميع الخصائص أولاً
            const forceReflow = document.body.offsetHeight;
            
            // تنفيذ callback
            callback();
            
            // إعادة السماح بالتصيير
            requestAnimationFrame(() => {
                document.body.classList.remove('freeze-layout');
            });
        });
    }

    /**
     * تقسيم المهام الكبيرة إلى قطع
     */
    async processInChunks(action, data = null) {
        const CHUNK_SIZE = 50; // حجم القطعة المثالي للأداء
        const totalItems = data?.length || this.getTotalItems();
        
        for (let i = 0; i < totalItems; i += CHUNK_SIZE) {
            // السماح للخيط الرئيسي بالتنفس
            await this.yieldToMainThread();
            
            const chunkEnd = Math.min(i + CHUNK_SIZE, totalItems);
            
            // معالجة القطعة
            await this.processChunk(action, i, chunkEnd);
            
            // تحديث التقدم
            this.updateProgress(i, totalItems);
        }
    }

    /**
     * السماح للخيط الرئيسي بالتعامل مع الأحداث الأخرى
     */
    yieldToMainThread() {
        return new Promise(resolve => {
            setTimeout(resolve, 0);
            // أو استخدام requestIdleCallback إذا متاح
            if ('requestIdleCallback' in window) {
                requestIdleCallback(resolve, { timeout: 50 });
            } else {
                setTimeout(resolve, 0);
            }
        });
    }

    /**
     * تحديث الواجهة بكفاءة
     */
    async updateUIPerformant() {
        // استخدام Document Fragment
        const fragment = document.createDocumentFragment();
        
        // إنشاء العناصر خارج DOM
        const elements = this.createReportElements();
        elements.forEach(el => fragment.appendChild(el));
        
        // إضافة كل شيء دفعة واحدة
        const container = document.getElementById('report-container');
        
        // استخدام طريقة استبدال سريعة
        this.replaceContentSmoothly(container, fragment);
    }

    /**
     * استبدال المحتوى بسلاسة
     */
    replaceContentSmoothly(container, newContent) {
        // تخفيف العناصر القديمة
        container.style.opacity = '0';
        
        // الانتظار للانتقال
        requestAnimationFrame(() => {
            // تفريغ المحتوى القديم
            while (container.firstChild) {
                container.removeChild(container.firstChild);
            }
            
            // إضافة المحتوى الجديد
            container.appendChild(newContent);
            
            // إظهار المحتوى الجديد
            requestAnimationFrame(() => {
                container.style.opacity = '1';
                container.style.transition = 'opacity 150ms ease-in-out';
            });
        });
    }

    /**
     * إظهار حالة التحميل
     */
    showLoadingState(button) {
        const originalHTML = button.innerHTML;
        button.dataset.originalHtml = originalHTML;
        
        button.innerHTML = `
            <span class="spinner"></span>
            جاري التحميل...
        `;
        button.disabled = true;
        
        // إضافة أنماط CSS للمؤشر
        this.addSpinnerStyles();
    }

    /**
     * إخفاء حالة التحميل
     */
    hideLoadingState(button) {
        const originalHTML = button.dataset.originalHtml;
        if (originalHTML) {
            button.innerHTML = originalHTML;
        }
        button.disabled = false;
    }

    /**
     * إضافة أنماط CSS للمؤشر
     */
    addSpinnerStyles() {
        if (!document.getElementById('spinner-styles')) {
            const style = document.createElement('style');
            style.id = 'spinner-styles';
            style.textContent = `
                .spinner {
                    display: inline-block;
                    width: 16px;
                    height: 16px;
                    border: 2px solid #f3f3f3;
                    border-top: 2px solid #3498db;
                    border-radius: 50%;
                    animation: spin 1s linear infinite;
                    margin-left: 8px;
                }
                
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
                
                .freeze-layout * {
                    animation: none !important;
                    transition: none !important;
                }
            `;
            document.head.appendChild(style);
        }
    }

    /**
     * التحقق مما إذا كان يجب استخدام Web Worker
     */
    shouldUseWorker(action) {
        const heavyActions = ['export', 'analyze', 'calculate', 'process-big-data'];
        return heavyActions.includes(action) && window.Worker;
    }

    /**
     * المعالجة باستخدام Web Worker
     */
    async processWithWorker(action) {
        return new Promise((resolve, reject) => {
            const worker = new Worker('report-worker.js');
            
            worker.postMessage({
                action: action,
                data: this.getReportData()
            });
            
            worker.onmessage = (e) => {
                resolve(e.data);
                worker.terminate();
            };
            
            worker.onerror = (error) => {
                reject(error);
                worker.terminate();
            };
            
            // timeout للسلامة
            setTimeout(() => {
                worker.terminate();
                reject(new Error('Worker timeout'));
            }, 30000);
        });
    }

    /**
     * عرض الأخطاء
     */
    showError(error) {
        console.error('Report processing error:', error);
        // يمكنك إضافة عرض خطأ للمستخدم هنا
    }

    // دالات مساعدة (تخصيص حسب حاجتك)
    getTotalItems() { return 1000; }
    getReportData() { return []; }
    createReportElements() { return []; }
    updateCellSelection() { }
    updateProgress() { }
    processChunk() { return Promise.resolve(); }
}

// تهيئة المحسن عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    window.reportOptimizer = new ReportPerformanceOptimizer();
});