// ============================================
// 📍 إدارة العيادات - الإصدار المصحح
// ============================================

// فتح نموذج إضافة عيادة
function openAddClinicModal() {
    const modal = document.getElementById('addClinicModal');
    if (modal) {
        modal.style.display = 'flex';
        
        // تعيين القيم الافتراضية
        if (document.getElementById('clinicName')) {
            document.getElementById('clinicName').value = '';
            document.getElementById('clinicLocation').value = '';
            document.getElementById('clinicType').value = 'general';
            document.getElementById('clinicCapacity').value = '20';
            document.getElementById('openingTime').value = '09:00';
            document.getElementById('closingTime').value = '17:00';
        }
    } else {
        console.error('❌ النموذج غير موجود!');
        createClinicModal();
    }
}

// إنشاء النموذج إذا لم يكن موجوداً
function createClinicModal() {
    const modalHTML = `
        <div id="addClinicModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center;">
            <div style="background: white; padding: 30px; border-radius: 15px; width: 90%; max-width: 500px;">
                <h2 style="margin-bottom: 20px; display: flex; align-items: center; gap: 10px;">
                    <i class="fas fa-plus"></i> إضافة عيادة جديدة
                </h2>
                <form id="addClinicForm">
                    <div style="margin-bottom: 15px;">
                        <label style="display: block; margin-bottom: 5px;">اسم العيادة *</label>
                        <input type="text" id="clinicName" class="form-control" placeholder="مثال: العيادة العامة" required>
                    </div>
                    <div style="margin-bottom: 15px;">
                        <label style="display: block; margin-bottom: 5px;">الموقع *</label>
                        <input type="text" id="clinicLocation" class="form-control" placeholder="مثال: الطابق الأول - غرفة 101" required>
                    </div>
                    <div style="margin-bottom: 15px;">
                        <label style="display: block; margin-bottom: 5px;">نوع العيادة *</label>
                        <select id="clinicType" class="form-control" required>
                            <option value="general">عيادة عامة</option>
                            <option value="pediatric">عيادة أطفال</option>
                            <option value="cardio">عيادة قلب</option>
                            <option value="ortho">عيادة عظام</option>
                        </select>
                    </div>
                    <div style="margin-bottom: 15px;">
                        <label style="display: block; margin-bottom: 5px;">السعة اليومية</label>
                        <input type="number" id="clinicCapacity" class="form-control" value="20" min="5" max="100">
                    </div>
                    <div style="display: flex; gap: 15px; margin-top: 25px;">
                        <button type="button" class="btn btn-outline" onclick="closeAddClinicModal()">
                            <i class="fas fa-times"></i> إلغاء
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> حفظ العيادة
                        </button>
                    </div>
                </form>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    // إعداد حدث الإرسال
    document.getElementById('addClinicForm').addEventListener('submit', handleAddClinicSubmit);
    
    // فتح النموذج
    setTimeout(() => {
        document.getElementById('addClinicModal').style.display = 'flex';
    }, 100);
}

// إغلاق نموذج إضافة عيادة
function closeAddClinicModal() {
    const modal = document.getElementById('addClinicModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

// معالجة إرسال نموذج إضافة عيادة
async function handleAddClinicSubmit(e) {
    e.preventDefault();
    
    // جمع البيانات من النموذج
    const clinicData = {
        clinic_name: document.getElementById('clinicName').value,
        floor_number: document.getElementById('clinicLocation').value,
        clinic_type: document.getElementById('clinicType').value,
        capacity: parseInt(document.getElementById('clinicCapacity').value) || 20,
        opening_time: document.getElementById('openingTime') ? 
                     document.getElementById('openingTime').value + ':00' : '09:00:00',
        closing_time: document.getElementById('closingTime') ? 
                     document.getElementById('closingTime').value + ':00' : '17:00:00'
    };
    
    // التحقق من البيانات
    if (!clinicData.clinic_name || !clinicData.floor_number || !clinicData.clinic_type) {
        showNotification('❌ يرجى ملء جميع الحقول المطلوبة', 'error');
        return;
    }
    
    console.log('📤 بيانات العيادة المرسلة:', clinicData);
    
    try {
        // إرسال البيانات إلى الخادم
        const response = await addClinic(clinicData);
        console.log('✅ استجابة الخادم:', response);
        
        // إغلاق النموذج
        closeAddClinicModal();
        
        // إعادة تحميل قائمة العيادات
        setTimeout(async () => {
            const clinics = await loadClinics();
            console.log('🔄 العيادات المحملة:', clinics);
            renderClinicsCards(clinics);
        }, 500);
        
        // إعادة تعيين النموذج
        const form = document.getElementById('addClinicForm');
        if (form) form.reset();
        
    } catch (error) {
        console.error('❌ خطأ في إضافة العيادة:', error);
        showNotification(`❌ ${error.message || 'حدث خطأ أثناء إضافة العيادة'}`, 'error');
    }
}

// تهيئة صفحة العيادات
function initClinicsPage() {
    console.log('🚀 تهيئة صفحة العيادات...');
    
    // تحميل العيادات
    loadClinics().then(clinics => {
        console.log(`✅ تم تحميل ${clinics.length} عيادة`);
        renderClinicsCards(clinics);
    }).catch(error => {
        console.error('❌ خطأ في تحميل العيادات:', error);
        showNotification('❌ خطأ في تحميل العيادات', 'error');
    });
    
    // إعداد زر الإضافة
    const addButton = document.querySelector('.btn-primary[onclick*="openAddClinicModal"], .btn-primary:has(i.fa-plus)');
    if (addButton) {
        addButton.onclick = openAddClinicModal;
    }
}

// تصدير الدوال
window.openAddClinicModal = openAddClinicModal;
window.closeAddClinicModal = closeAddClinicModal;
window.handleAddClinicSubmit = handleAddClinicSubmit;
window.initClinicsPage = initClinicsPage;

// تهيئة عند التحميل
document.addEventListener('DOMContentLoaded', function() {
    if (window.location.pathname.includes('clinics.html')) {
        initClinicsPage();
    }
});

console.log('✅ ملف إدارة العيادات جاهز!');