// db-connection.js - اتصال بقاعدة البيانات
const mysql = require('mysql2/promise');

const dbConfig = {
    host: 'localhost',
    user: 'root',
    password: '12345',
    database: 'clinic_management',
    port: 3306
};

async function testDatabase() {
    console.log('🔍 جاري اختبار اتصال قاعدة البيانات...');
    
    try {
        const connection = await mysql.createConnection(dbConfig);
        console.log('✅ ✅ ✅ نجح الاتصال بقاعدة البيانات!');
        
        const [tables] = await connection.execute('SHOW TABLES');
        console.log(`📊 عدد الجداول: ${tables.length}`);
        
        for (const table of tables) {
            const tableName = table.Tables_in_clinic_management;
            const [rows] = await connection.execute(`SELECT COUNT(*) as count FROM ${tableName}`);
            console.log(`   📁 ${tableName}: ${rows[0].count} سجل`);
        }
        
        connection.end();
        console.log('\n🎉 قاعدة البيانات جاهزة للاستخدام!');
        return true;
        
    } catch (error) {
        console.log('❌ فشل الاتصال بقاعدة البيانات');
        console.log(`🔧 الخطأ: ${error.message}`);
        
        console.log('\n💡 الحلول المقترحة:');
        console.log('1. تأكد من تشغيل MySQL');
        console.log('2. تحقق من كلمة المرور');
        console.log('3. جرب كلمة مرور فارغة: ""');
        return false;
    }
}

// اختبر الاتصال
testDatabase().then(success => {
    if (success) {
        console.log('\n✅ يمكنك الآن ربط قاعدة البيانات بالخادم!');
    } else {
        console.log('\n⚠️ استخدم بيانات وهمية للاستمرار');
    }
});