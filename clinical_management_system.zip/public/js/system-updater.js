/**
 * نظام تحديث clinic management  - System Updater
 * نظام إدارة وتحديث البيانات للنظام الطبي
 * الإصدار: 1.0.0
 */

(function() {
    'use strict';
    
    // التحقق من عدم تحميل النظام مرتين
    if (window.clinic management SystemLoaded) {
        console.warn('نظام clinic management  System Updater تم تحميله مسبقاً');
        return;
    }
    
    window.clinic management SystemLoaded = true;
    console.log('✅ نظام تحديث clinic management  جاهز للعمل');
    
    // بيانات النظام الافتراضية
    const clinic management _DATA = {
        // بيانات العيادات
        clinics: [
            {
                id: 'clinic-1',
                name: 'عيادة القلب والأوعية الدموية',
                department: 'cardiology',
                status: 'active',
                doctor: 'د. أحمد مصطفى',
                appointments: 156,
                capacity: 200,
                rating: 4.8,
                color: '#2563eb',
                location: 'الطابق الأول - الجناح أ',
                phone: '+20 100 200 3001',
                email: 'cardiology@clinic management clinic.com'
            },
            {
                id: 'clinic-2',
                name: 'عيادة العظام والروماتيزم',
                department: 'orthopedics',
                status: 'active',
                doctor: 'د. محمد السيد',
                appointments: 128,
                capacity: 150,
                rating: 4.7,
                color: '#10b981',
                location: 'الطابق الثاني - الجناح ب',
                phone: '+20 100 200 3002',
                email: 'orthopedics@clinic management clinic.com'
            },
            {
                id: 'clinic-3',
                name: 'عيادة الأطفال',
                department: 'pediatrics',
                status: 'active',
                doctor: 'د. سعاد محمد',
                appointments: 198,
                capacity: 180,
                rating: 4.9,
                color: '#8b5cf6',
                location: 'الطابق الأرضي - الجناح ج',
                phone: '+20 100 200 3003',
                email: 'pediatrics@clinic management clinic.com'
            },
            {
                id: 'clinic-4',
                name: 'عيادة الأمراض الجلدية',
                department: 'dermatology',
                status: 'active',
                doctor: 'د. منى فاروق',
                appointments: 95,
                capacity: 120,
                rating: 4.6,
                color: '#f59e0b',
                location: 'الطابق الثالث - الجناح د',
                phone: '+20 100 200 3004',
                email: 'dermatology@clinic management clinic.com'
            },
            {
                id: 'clinic-5',
                name: 'عيادة النساء والتوليد',
                department: 'gynecology',
                status: 'maintenance',
                doctor: 'د. هدى كمال',
                appointments: 0,
                capacity: 100,
                rating: 4.8,
                color: '#ec4899',
                location: 'الطابق الثاني - الجناح هـ',
                phone: '+20 100 200 3005',
                email: 'gynecology@clinic management clinic.com'
            },
            {
                id: 'clinic-6',
                name: 'عيادة الأنف والأذن والحنجرة',
                department: 'ent',
                status: 'active',
                doctor: 'د. عماد رشاد',
                appointments: 112,
                capacity: 130,
                rating: 4.5,
                color: '#06b6d4',
                location: 'الطابق الأول - الجناح و',
                phone: '+20 100 200 3006',
                email: 'ent@clinic management clinic.com'
            }
        ],
        
        // بيانات الأطباء
        doctors: [
            {
                id: 'doctor-1',
                name: 'د. أحمد مصطفى',
                specialty: 'أمراض القلب',
                clinicId: 'clinic-1',
                status: 'active',
                rating: 4.8,
                appointments: 156,
                phone: '+20 111 222 3331',
                email: 'ahmed.mostafa@clinic management clinic.com',
                schedule: {
                    monday: '9:00 ص - 5:00 م',
                    tuesday: '9:00 ص - 5:00 م',
                    wednesday: '9:00 ص - 2:00 م',
                    thursday: '9:00 ص - 5:00 م',
                    friday: 'إجازة',
                    saturday: '9:00 ص - 2:00 م',
                    sunday: 'إجازة'
                }
            },
            {
                id: 'doctor-2',
                name: 'د. محمد السيد',
                specialty: 'جراحة العظام',
                clinicId: 'clinic-2',
                status: 'active',
                rating: 4.7,
                appointments: 128,
                phone: '+20 111 222 3332',
                email: 'mohamed.sayed@clinic management clinic.com',
                schedule: {
                    monday: '10:00 ص - 6:00 م',
                    tuesday: '10:00 ص - 6:00 م',
                    wednesday: 'إجازة',
                    thursday: '10:00 ص - 6:00 م',
                    friday: '10:00 ص - 2:00 م',
                    saturday: '10:00 ص - 6:00 م',
                    sunday: 'إجازة'
                }
            },
            {
                id: 'doctor-3',
                name: 'د. سعاد محمد',
                specialty: 'طب الأطفال',
                clinicId: 'clinic-3',
                status: 'active',
                rating: 4.9,
                appointments: 198,
                phone: '+20 111 222 3333',
                email: 'saad.mohamed@clinic management clinic.com',
                schedule: {
                    monday: '8:00 ص - 4:00 م',
                    tuesday: '8:00 ص - 4:00 م',
                    wednesday: '8:00 ص - 4:00 م',
                    thursday: '8:00 ص - 4:00 م',
                    friday: '8:00 ص - 12:00 م',
                    saturday: '8:00 ص - 4:00 م',
                    sunday: 'إجازة'
                }
            },
            {
                id: 'doctor-4',
                name: 'د. منى فاروق',
                specialty: 'الأمراض الجلدية',
                clinicId: 'clinic-4',
                status: 'active',
                rating: 4.6,
                appointments: 95,
                phone: '+20 111 222 3334',
                email: 'mona.farouk@clinic management clinic.com',
                schedule: {
                    monday: '11:00 ص - 7:00 م',
                    tuesday: '11:00 ص - 7:00 م',
                    wednesday: '11:00 ص - 3:00 م',
                    thursday: '11:00 ص - 7:00 م',
                    friday: 'إجازة',
                    saturday: '11:00 ص - 7:00 م',
                    sunday: 'إجازة'
                }
            },
            {
                id: 'doctor-5',
                name: 'د. هدى كمال',
                specialty: 'النساء والتوليد',
                clinicId: 'clinic-5',
                status: 'on-leave',
                rating: 4.8,
                appointments: 0,
                phone: '+20 111 222 3335',
                email: 'hoda.kamal@clinic management clinic.com',
                schedule: {
                    monday: 'إجازة',
                    tuesday: 'إجازة',
                    wednesday: 'إجازة',
                    thursday: 'إجازة',
                    friday: 'إجازة',
                    saturday: 'إجازة',
                    sunday: 'إجازة'
                }
            },
            {
                id: 'doctor-6',
                name: 'د. عماد رشاد',
                specialty: 'أنف وأذن وحنجرة',
                clinicId: 'clinic-6',
                status: 'active',
                rating: 4.5,
                appointments: 112,
                phone: '+20 111 222 3336',
                email: 'emad.rashad@clinic management clinic.com',
                schedule: {
                    monday: '9:00 ص - 5:00 م',
                    tuesday: '9:00 ص - 5:00 م',
                    wednesday: '9:00 ص - 5:00 م',
                    thursday: '9:00 ص - 1:00 م',
                    friday: '9:00 ص - 5:00 م',
                    saturday: 'إجازة',
                    sunday: 'إجازة'
                }
            }
        ],
        
        // بيانات المرضى
        patients: [
            {
                id: 'P-1001',
                firstName: 'أحمد',
                lastName: 'محمد',
                fullName: 'أحمد محمد',
                phone: '+20 100 200 3001',
                email: 'ahmed@email.com',
                birthDate: '1985-05-15',
                gender: 'male',
                lastVisit: '2024-12-20',
                visits: 12,
                status: 'active',
                type: 'regular',
                address: 'القاهرة، مصر',
                medicalNotes: 'ضغط دم مرتفع، يحتاج مراقبة مستمرة'
            },
            {
                id: 'P-1002',
                firstName: 'سارة',
                lastName: 'خالد',
                fullName: 'سارة خالد',
                phone: '+20 100 200 3002',
                email: 'sara@email.com',
                birthDate: '1990-08-22',
                gender: 'female',
                lastVisit: '2024-12-21',
                visits: 8,
                status: 'active',
                type: 'regular',
                address: 'الإسكندرية، مصر',
                medicalNotes: 'لا توجد ملاحظات'
            }
        ],
        
        // بيانات المواعيد
        appointments: [
            {
                id: 'A-1001',
                patientId: 'P-1001',
                patientName: 'أحمد محمد',
                clinicId: 'clinic-1',
                clinicName: 'عيادة القلب والأوعية الدموية',
                doctorId: 'doctor-1',
                doctorName: 'د. أحمد مصطفى',
                date: '2024-12-26',
                time: '10:00',
                status: 'confirmed',
                type: 'follow-up',
                notes: 'فحص دوري للقلب'
            }
        ]
    };
    
    // كشف البيانات للاستخدام العالمي
    window.clinic management _DATA = clinic management _DATA;
    
    // وظائف النظام
    const SystemUpdater = {
        
        /**
         * تهيئة النظام
         */
        initialize: function() {
            console.log('🚀 تهيئة نظام تحديث clinic management ...');
            
            // تحميل البيانات المحفوظة من localStorage
            this.loadSavedData();
            
            // تحديث الصفحة الحالية
            this.updateCurrentPage();
            
            // إعداد مستمعات الأحداث
            this.setupEventListeners();
            
            console.log('✅ تم تهيئة النظام بنجاح');
        },
        
        /**
         * تحميل البيانات المحفوظة
         */
        loadSavedData: function() {
            try {
                // محاولة تحميل البيانات من localStorage
                const savedClinics = localStorage.getItem('clinic management _clinics');
                const savedDoctors = localStorage.getItem('clinic management _doctors');
                const savedPatients = localStorage.getItem('clinic management _patients');
                const savedAppointments = localStorage.getItem('clinic management _appointments');
                
                if (savedClinics) {
                    clinic management _DATA.clinics = JSON.parse(savedClinics);
                    console.log('📂 تم تحميل بيانات العيادات من التخزين المحلي');
                }
                
                if (savedDoctors) {
                    clinic management _DATA.doctors = JSON.parse(savedDoctors);
                    console.log('📂 تم تحميل بيانات الأطباء من التخزين المحلي');
                }
                
                if (savedPatients) {
                    clinic management _DATA.patients = JSON.parse(savedPatients);
                    console.log('📂 تم تحميل بيانات المرضى من التخزين المحلي');
                }
                
                if (savedAppointments) {
                    clinic management _DATA.appointments = JSON.parse(savedAppointments);
                    console.log('📂 تم تحميل بيانات المواعيد من التخزين المحلي');
                }
                
            } catch (error) {
                console.error('❌ خطأ في تحميل البيانات المحفوظة:', error);
            }
        },
        
        /**
         * حفظ البيانات
         */
        saveData: function() {
            try {
                localStorage.setItem('clinic management _clinics', JSON.stringify(clinic management _DATA.clinics));
                localStorage.setItem('clinic management _doctors', JSON.stringify(clinic management _DATA.doctors));
                localStorage.setItem('clinic management _patients', JSON.stringify(clinic management _DATA.patients));
                localStorage.setItem('clinic management _appointments', JSON.stringify(clinic management _DATA.appointments));
                
                // إطلاق حدث تحديث التخزين
                this.triggerStorageUpdate();
                
                console.log('💾 تم حفظ جميع البيانات بنجاح');
                return true;
            } catch (error) {
                console.error('❌ خطأ في حفظ البيانات:', error);
                return false;
            }
        },
        
        /**
         * إطلاق حدث تحديث التخزين
         */
        triggerStorageUpdate: function() {
            // إنشاء حدث تحديث التخزين
            const updateEvent = new CustomEvent('clinic management StorageUpdate', {
                detail: { timestamp: new Date().toISOString() }
            });
            
            // إطلاق الحدث
            window.dispatchEvent(updateEvent);
            
            // تحديث localStorage (للتزامن بين التبويبات)
            localStorage.setItem('clinic management _last_update', new Date().toISOString());
        },
        
        /**
         * تحديث الصفحة الحالية
         */
        updateCurrentPage: function() {
            const path = window.location.pathname;
            const pageName = path.split('/').pop();
            
            switch(pageName) {
                case 'clinics.html':
                    this.updateClinicsPage();
                    break;
                case 'doctors.html':
                    this.updateDoctorsPage();
                    break;
                case 'patients.html':
                    this.updatePatientsPage();
                    break;
                case 'all-bookings.html':
                    this.updateAppointmentsPage();
                    break;
                case 'dashboard.html':
                    this.updateDashboardPage();
                    break;
                default:
                    console.log('📄 الصفحة الحالية:', pageName);
            }
        },
        
        /**
         * تحديث صفحة العيادات
         */
        updateClinicsPage: function() {
            console.log('🔄 تحديث صفحة العيادات...');
            
            // هنا يمكنك إضافة منطق تحديث صفحة العيادات
            // مثل تحديث الجداول والإحصائيات
        },
        
        /**
         * تحديث صفحة الأطباء
         */
        updateDoctorsPage: function() {
            console.log('🔄 تحديث صفحة الأطباء...');
            
            // تحديث قائمة الأطباء في نموذج إضافة مريض إذا كان موجوداً
            this.updateDoctorsInPatientForm();
        },
        
        /**
         * تحديث صفحة المرضى
         */
        updatePatientsPage: function() {
            console.log('🔄 تحديث صفحة المرضى...');
            
            // تحديث قائمة الأطباء في نموذج إضافة مريض
            this.updateDoctorsInPatientForm();
        },
        
        /**
         * تحديث نموذج إضافة مريض
         */
        updateDoctorsInPatientForm: function() {
            const doctorSelect = document.querySelector('select#assignedDoctor, select[name="doctor"], .doctor-select');
            
            if (doctorSelect) {
                // حفظ الاختيار الحالي
                const currentValue = doctorSelect.value;
                
                // مسح الخيارات الحالية
                doctorSelect.innerHTML = '';
                
                // إضافة خيار افتراضي
                const defaultOption = document.createElement('option');
                defaultOption.value = '';
                defaultOption.textContent = 'اختر الطبيب';
                doctorSelect.appendChild(defaultOption);
                
                // إضافة الأطباء
                clinic management _DATA.doctors.forEach(doctor => {
                    if (doctor.status === 'active') {
                        const option = document.createElement('option');
                        option.value = doctor.id;
                        option.textContent = `${doctor.name} - ${doctor.specialty}`;
                        doctorSelect.appendChild(option);
                    }
                });
                
                // استعادة الاختيار السابق إذا كان موجوداً
                if (currentValue) {
                    doctorSelect.value = currentValue;
                }
                
                console.log('👨‍⚕️ تم تحديث قائمة الأطباء في النموذج');
            }
        },
        
        /**
         * تحديث صفحة المواعيد
         */
        updateAppointmentsPage: function() {
            console.log('🔄 تحديث صفحة المواعيد...');
        },
        
        /**
         * تحديث لوحة التحكم
         */
        updateDashboardPage: function() {
            console.log('🔄 تحديث لوحة التحكم...');
            
            // تحديث الإحصائيات
            this.updateDashboardStats();
        },
        
        /**
         * تحديث إحصائيات لوحة التحكم
         */
        updateDashboardStats: function() {
            // حساب الإحصائيات
            const stats = {
                totalClinics: clinic management _DATA.clinics.length,
                activeClinics: clinic management _DATA.clinics.filter(c => c.status === 'active').length,
                totalDoctors: clinic management _DATA.doctors.length,
                activeDoctors: clinic management _DATA.doctors.filter(d => d.status === 'active').length,
                totalPatients: clinic management _DATA.patients.length,
                activePatients: clinic management _DATA.patients.filter(p => p.status === 'active').length,
                totalAppointments: clinic management _DATA.appointments.length,
                todayAppointments: clinic management _DATA.appointments.filter(a => {
                    const today = new Date().toISOString().split('T')[0];
                    return a.date === today;
                }).length
            };
            
            // تحديث عناصر الإحصائيات في الصفحة
            this.updateStatElement('totalClinics', stats.totalClinics);
            this.updateStatElement('activeClinics', stats.activeClinics);
            this.updateStatElement('totalDoctors', stats.totalDoctors);
            this.updateStatElement('activeDoctors', stats.activeDoctors);
            this.updateStatElement('totalPatients', stats.totalPatients);
            this.updateStatElement('activePatients', stats.activePatients);
            this.updateStatElement('totalAppointments', stats.totalAppointments);
            this.updateStatElement('todayAppointments', stats.todayAppointments);
        },
        
        /**
         * تحديث عنصر إحصائي
         */
        updateStatElement: function(elementId, value) {
            const element = document.getElementById(elementId);
            if (element) {
                element.textContent = value;
            }
        },
        
        /**
         * إعداد مستمعات الأحداث
         */
        setupEventListeners: function() {
            // الاستماع لتحديثات التخزين من التبويبات الأخرى
            window.addEventListener('storage', (e) => {
                if (e.key === 'clinic management _last_update') {
                    console.log('📡 تم تحديث البيانات من تبويب آخر، جاري إعادة التحميل...');
                    this.loadSavedData();
                    this.updateCurrentPage();
                }
            });
            
            // الاستماع لأحداث النظام المخصصة
            window.addEventListener('clinic management DataChanged', () => {
                console.log('🔄 حدث تغيير بيانات، جاري الحفظ...');
                this.saveData();
            });
            
            // حفظ البيانات عند إغلاق الصفحة
            window.addEventListener('beforeunload', () => {
                this.saveData();
            });
            
            console.log('🎧 تم إعداد مستمعات الأحداث');
        },
        
        /**
         * إضافة عيادة جديدة
         */
        addClinic: function(clinicData) {
            const newClinic = {
                id: `clinic-${Date.now()}`,
                ...clinicData,
                status: clinicData.status || 'active',
                appointments: 0,
                rating: 0
            };
            
            clinic management _DATA.clinics.push(newClinic);
            this.saveData();
            
            console.log('✅ تم إضافة عيادة جديدة:', newClinic.name);
            return newClinic.id;
        },
        
        /**
         * تحديث عيادة
         */
        updateClinic: function(clinicId, updates) {
            const index = clinic management _DATA.clinics.findIndex(c => c.id === clinicId);
            if (index !== -1) {
                clinic management _DATA.clinics[index] = { ...clinic management _DATA.clinics[index], ...updates };
                this.saveData();
                
                console.log('✅ تم تحديث العيادة:', clinicId);
                return true;
            }
            return false;
        },
        
        /**
         * حذف عيادة
         */
        deleteClinic: function(clinicId) {
            const index = clinic management _DATA.clinics.findIndex(c => c.id === clinicId);
            if (index !== -1) {
                clinic management _DATA.clinics.splice(index, 1);
                this.saveData();
                
                console.log('🗑️ تم حذف العيادة:', clinicId);
                return true;
            }
            return false;
        },
        
        /**
         * الحصول على جميع العيادات
         */
        getAllClinics: function() {
            return [...clinic management _DATA.clinics];
        },
        
        /**
         * الحصول على عيادة بالمعرف
         */
        getClinicById: function(clinicId) {
            return clinic management _DATA.clinics.find(c => c.id === clinicId) || null;
        },
        
        /**
         * الحصول على عيادات القسم
         */
        getClinicsByDepartment: function(department) {
            return clinic management _DATA.clinics.filter(c => c.department === department);
        },
        
        /**
         * إضافة طبيب جديد
         */
        addDoctor: function(doctorData) {
            const newDoctor = {
                id: `doctor-${Date.now()}`,
                ...doctorData,
                status: doctorData.status || 'active',
                appointments: 0,
                rating: 0
            };
            
            clinic management _DATA.doctors.push(newDoctor);
            this.saveData();
            
            console.log('✅ تم إضافة طبيب جديد:', newDoctor.name);
            return newDoctor.id;
        },
        
        /**
         * الحصول على جميع الأطباء
         */
        getAllDoctors: function() {
            return [...clinic management _DATA.doctors];
        },
        
        /**
         * الحصول على أطباء العيادة
         */
        getDoctorsByClinic: function(clinicId) {
            return clinic management _DATA.doctors.filter(d => d.clinicId === clinicId);
        },
        
        /**
         * إضافة مريض جديد
         */
        addPatient: function(patientData) {
            const newPatient = {
                id: `P-${1000 + clinic management _DATA.patients.length + 1}`,
                ...patientData,
                status: 'active',
                visits: 1,
                lastVisit: new Date().toISOString().split('T')[0]
            };
            
            clinic management _DATA.patients.push(newPatient);
            this.saveData();
            
            // إطلاق حدث تحديث المرضى
            const event = new CustomEvent('clinic management PatientAdded', {
                detail: { patient: newPatient }
            });
            window.dispatchEvent(event);
            
            console.log('✅ تم إضافة مريض جديد:', newPatient.fullName);
            return newPatient.id;
        },
        
        /**
         * الحصول على جميع المرضى
         */
        getAllPatients: function() {
            return [...clinic management _DATA.patients];
        },
        
        /**
         * إضافة موعد جديد
         */
        addAppointment: function(appointmentData) {
            const newAppointment = {
                id: `A-${1000 + clinic management _DATA.appointments.length + 1}`,
                ...appointmentData,
                status: 'pending'
            };
            
            clinic management _DATA.appointments.push(newAppointment);
            this.saveData();
            
            console.log('✅ تم إضافة موعد جديد:', newAppointment.id);
            return newAppointment.id;
        },
        
        /**
         * الحصول على مواعيد المريض
         */
        getPatientAppointments: function(patientId) {
            return clinic management _DATA.appointments.filter(a => a.patientId === patientId);
        },
        
        /**
         * الحصول على مواعيد العيادة
         */
        getClinicAppointments: function(clinicId) {
            return clinic management _DATA.appointments.filter(a => a.clinicId === clinicId);
        },
        
        /**
         * تصدير البيانات
         */
        exportData: function() {
            const dataStr = JSON.stringify(clinic management _DATA, null, 2);
            const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
            
            const exportFileDefaultName = `clinic management -backup-${new Date().toISOString().split('T')[0]}.json`;
            
            const linkElement = document.createElement('a');
            linkElement.setAttribute('href', dataUri);
            linkElement.setAttribute('download', exportFileDefaultName);
            linkElement.click();
            
            console.log('📤 تم تصدير البيانات بنجاح');
        },
        
        /**
         * استيراد البيانات
         */
        importData: function(jsonData) {
            try {
                const importedData = JSON.parse(jsonData);
                
                // التحقق من بنية البيانات
                if (importedData.clinics && importedData.doctors && importedData.patients) {
                    clinic management _DATA.clinics = importedData.clinics;
                    clinic management _DATA.doctors = importedData.doctors;
                    clinic management _DATA.patients = importedData.patients;
                    clinic management _DATA.appointments = importedData.appointments || [];
                    
                    this.saveData();
                    
                    // إعادة تحميل الصفحة
                    location.reload();
                    
                    console.log('📥 تم استيراد البيانات بنجاح');
                    return true;
                } else {
                    console.error('❌ بنية البيانات غير صالحة');
                    return false;
                }
            } catch (error) {
                console.error('❌ خطأ في استيراد البيانات:', error);
                return false;
            }
        },
        
        /**
         * إعادة تعيين البيانات
         */
        resetData: function() {
            if (confirm('⚠️ هل أنت متأكد من إعادة تعيين جميع البيانات؟ هذا الإجراء لا يمكن التراجع عنه.')) {
                localStorage.clear();
                location.reload();
            }
        },
        
        /**
         * الحصول على إحصائيات النظام
         */
        getSystemStats: function() {
            return {
                clinics: clinic management _DATA.clinics.length,
                doctors: clinic management _DATA.doctors.length,
                patients: clinic management _DATA.patients.length,
                appointments: clinic management _DATA.appointments.length,
                lastUpdate: localStorage.getItem('clinic management _last_update') || 'لم يتم الحفظ بعد'
            };
        }
    };
    
    // كشف SystemUpdater للاستخدام العالمي
    window.SystemUpdater = SystemUpdater;
    
    // تهيئة النظام عند تحميل الصفحة
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            setTimeout(() => SystemUpdater.initialize(), 100);
        });
    } else {
        setTimeout(() => SystemUpdater.initialize(), 100);
    }
    
})();

// ملاحظة: هذا الملف يعمل مع جميع صفحات النظام
// يتم تحميله مرة واحدة فقط لكل صفحة