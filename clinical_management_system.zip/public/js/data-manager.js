// نظام إدارة البيانات - النسخة مع دعم API
class DataManager {
    constructor() {
        this.API_BASE_URL = 'http://localhost:3000/api';
        this.patients = [];
        this.doctors = [];
        this.clinics = [];
        this.appointments = [];
        this.initializeData();
    }

    async initializeData() {
        console.log('🚀 تهيئة DataManager...');
        try {
            // محاولة تحميل البيانات من API
            const isConnected = await this.checkAPIConnection();
            if (isConnected) {
                await this.loadFromAPI();
            } else {
                console.log('⚠️ استخدام البيانات المحلية (API غير متاح)');
                this.loadFromLocalStorage();
            }
        } catch (error) {
            console.error('❌ خطأ في التهيئة:', error);
            this.loadFromLocalStorage();
        }
    }

    async checkAPIConnection() {
        try {
            const response = await fetch(`${this.API_BASE_URL}/health`, {
                timeout: 3000
            });
            return response.ok;
        } catch (error) {
            return false;
        }
    }

    async loadFromAPI() {
        try {
            console.log('📥 جاري تحميل البيانات من API...');
            
            const [patients, doctors, clinics, appointments] = await Promise.all([
                this.fetchData('/patients'),
                this.fetchData('/doctors'),
                this.fetchData('/clinics'),
                this.fetchData('/appointments')
            ]);

            this.patients = patients || [];
            this.doctors = doctors || [];
            this.clinics = clinics || [];
            this.appointments = appointments || [];

            // حفظ نسخة محلية
            this.saveToLocalStorage();
            
            console.log(`✅ تم تحميل البيانات من API:
            - ${this.patients.length} مريض
            - ${this.doctors.length} طبيب
            - ${this.clinics.length} عيادة
            - ${this.appointments.length} حجز`);
            
        } catch (error) {
            console.error('❌ فشل تحميل البيانات من API:', error);
            throw error;
        }
    }

    async fetchData(endpoint) {
        try {
            const response = await fetch(`${this.API_BASE_URL}${endpoint}`);
            if (!response.ok) {
                throw new Error(`خطأ في API: ${response.status}`);
            }
            return await response.json();
        } catch (error) {
            console.error(`❌ خطأ في جلب ${endpoint}:`, error);
            return [];
        }
    }

    async postData(endpoint, data) {
        try {
            const response = await fetch(`${this.API_BASE_URL}${endpoint}`, {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(data)
            });
            
            if (!response.ok) {
                throw new Error(`خطأ في API: ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error(`❌ خطأ في POST إلى ${endpoint}:`, error);
            throw error;
        }
    }

    async putData(endpoint, data) {
        try {
            const response = await fetch(`${this.API_BASE_URL}${endpoint}`, {
                method: 'PUT',
                headers: { 
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(data)
            });
            
            if (!response.ok) {
                throw new Error(`خطأ في API: ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error(`❌ خطأ في PUT إلى ${endpoint}:`, error);
            throw error;
        }
    }

    async deleteData(endpoint) {
        try {
            const response = await fetch(`${this.API_BASE_URL}${endpoint}`, {
                method: 'DELETE'
            });
            
            if (!response.ok) {
                throw new Error(`خطأ في API: ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error(`❌ خطأ في DELETE ${endpoint}:`, error);
            throw error;
        }
    }

    loadFromLocalStorage() {
        console.log('📂 جاري تحميل البيانات من التخزين المحلي...');
        
        try {
            this.patients = JSON.parse(localStorage.getItem('clinic management _patients')) || [];
            this.doctors = JSON.parse(localStorage.getItem('clinic management _doctors')) || [];
            this.clinics = JSON.parse(localStorage.getItem('clinic management _clinics')) || [];
            this.appointments = JSON.parse(localStorage.getItem('clinic management _appointments')) || [];
            
            console.log(`✅ تم تحميل البيانات المحلية:
            - ${this.patients.length} مريض
            - ${this.doctors.length} طبيب
            - ${this.clinics.length} عيادة
            - ${this.appointments.length} حجز`);
            
        } catch (error) {
            console.error('❌ خطأ في تحميل البيانات المحلية:', error);
            this.loadSampleData();
        }
    }

    saveToLocalStorage() {
        try {
            localStorage.setItem('clinic management _patients', JSON.stringify(this.patients));
            localStorage.setItem('clinic management _doctors', JSON.stringify(this.doctors));
            localStorage.setItem('clinic management _clinics', JSON.stringify(this.clinics));
            localStorage.setItem('clinic management _appointments', JSON.stringify(this.appointments));
        } catch (error) {
            console.error('❌ خطأ في حفظ البيانات المحلية:', error);
        }
    }

    loadSampleData() {
        console.log('📋 تحميل بيانات نموذجية...');
        
        // بيانات عينة للمرضى
        this.patients = [
            {
                id: 1,
                name: "أحمد محمد علي",
                phone: "+20 100 000 0001",
                age: 35,
                gender: "ذكر",
                email: "ahmed@example.com",
                address: "القاهرة، مصر",
                bloodType: "A+",
                emergencyContact: "+20 100 000 0002",
                allergies: "حساسية من البنسلين",
                chronicDiseases: "لا يوجد",
                notes: "مريض منتظم",
                status: "active",
                totalVisits: 5,
                lastVisit: new Date().toISOString().split('T')[0],
                createdAt: "2024-01-15"
            },
            {
                id: 2,
                name: "سارة محمود حسين",
                phone: "+20 100 000 0003",
                age: 28,
                gender: "أنثى",
                email: "sara@example.com",
                address: "الإسكندرية، مصر",
                bloodType: "O+",
                emergencyContact: "+20 100 000 0004",
                allergies: "لا يوجد",
                chronicDiseases: "ضغط الدم",
                notes: "تأتي للمتابعة شهرياً",
                status: "active",
                totalVisits: 3,
                lastVisit: "2024-03-15",
                createdAt: "2024-02-20"
            }
        ];

        // بيانات عينة للأطباء
        this.doctors = [
            {
                id: 1,
                firstName: "محمود",
                lastName: "عبدالرحمن",
                fullName: "د. محمود عبدالرحمن",
                specialty: "أخصائي طب عام",
                specialtyValue: "general",
                clinic: "العيادة العامة",
                phone: "+20 100 200 3000",
                email: "dr.mahmoud@clinic.com",
                qualifications: "دكتوراه في الطب الباطني",
                rating: 4.8,
                patientsPerDay: 25,
                status: "available",
                schedule: {
                    "الإثنين - الخميس": "9:00 ص - 5:00 م",
                    "الجمعة": "10:00 ص - 2:00 م"
                },
                appointments: 12,
                joinedDate: "2024-01-15"
            }
        ];

        // بيانات عينة للعيادات
        this.clinics = [
            {
                id: 1,
                name: "العيادة العامة",
                type: "general",
                doctorId: 1,
                doctor: "د. محمود عبدالرحمن",
                floor: "الأول",
                room: "101",
                capacity: 25,
                openingTime: "09:00",
                closingTime: "17:00",
                phone: "+20 100 300 4000",
                email: "general@clinic.com",
                color: "#2563eb",
                status: "active",
                description: "العيادة العامة للمراجعات الأولية والتشخيص",
                updatedAt: new Date().toISOString()
            }
        ];

        // بيانات عينة للحجوزات
        this.appointments = [
            {
                id: 1,
                patientId: 1,
                patientName: "أحمد محمد علي",
                doctorId: 1,
                doctorName: "د. محمود عبدالرحمن",
                clinicId: 1,
                clinicName: "العيادة العامة",
                appointmentDate: new Date().toISOString().split('T')[0],
                appointmentTime: "10:00",
                status: "confirmed",
                reason: "كشف دوري",
                notes: "يحتاج إلى تحاليل دم",
                fee: 150,
                createdAt: new Date().toISOString()
            }
        ];

        this.saveToLocalStorage();
    }

    // ============ إدارة المرضى ============
    getPatients() {
        return [...this.patients];
    }

    getPatient(id) {
        return this.patients.find(p => p.id === id);
    }

    async addPatient(patientData) {
        try {
            // محاولة الحفظ عبر API أولاً
            const isConnected = await this.checkAPIConnection();
            if (isConnected) {
                const newPatient = await this.postData('/patients', patientData);
                this.patients.push(newPatient);
                this.saveToLocalStorage();
                return newPatient;
            } else {
                // استخدام النظام المحلي
                return this.addPatientLocal(patientData);
            }
        } catch (error) {
            console.error('❌ خطأ في إضافة المريض:', error);
            return this.addPatientLocal(patientData);
        }
    }

    addPatientLocal(patientData) {
        const newPatient = {
            id: this.generateId(),
            ...patientData,
            patientId: `PAT${String(this.patients.length + 1).padStart(4, '0')}`,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            totalVisits: 0,
            lastVisit: null
        };
        
        this.patients.push(newPatient);
        this.saveToLocalStorage();
        return newPatient;
    }

    async updatePatient(id, updates) {
        try {
            const isConnected = await this.checkAPIConnection();
            if (isConnected) {
                const updatedPatient = await this.putData(`/patients/${id}`, updates);
                const index = this.patients.findIndex(p => p.id === id);
                if (index !== -1) {
                    this.patients[index] = { ...this.patients[index], ...updatedPatient, updatedAt: new Date().toISOString() };
                    this.saveToLocalStorage();
                }
                return updatedPatient;
            } else {
                return this.updatePatientLocal(id, updates);
            }
        } catch (error) {
            console.error('❌ خطأ في تحديث المريض:', error);
            return this.updatePatientLocal(id, updates);
        }
    }

    updatePatientLocal(id, updates) {
        const index = this.patients.findIndex(p => p.id === id);
        if (index !== -1) {
            this.patients[index] = { 
                ...this.patients[index], 
                ...updates, 
                updatedAt: new Date().toISOString() 
            };
            this.saveToLocalStorage();
            return this.patients[index];
        }
        return null;
    }

    async deletePatient(id) {
        try {
            const isConnected = await this.checkAPIConnection();
            if (isConnected) {
                await this.deleteData(`/patients/${id}`);
            }
            
            const index = this.patients.findIndex(p => p.id === id);
            if (index !== -1) {
                this.patients.splice(index, 1);
                this.saveToLocalStorage();
                return { success: true, message: "تم حذف المريض بنجاح" };
            }
            
            return { success: false, error: "المريض غير موجود" };
        } catch (error) {
            console.error('❌ خطأ في حذف المريض:', error);
            return { success: false, error: "حدث خطأ أثناء حذف المريض" };
        }
    }

    // ============ إدارة الأطباء ============
    getDoctors() {
        return [...this.doctors];
    }

    getDoctor(id) {
        return this.doctors.find(d => d.id === id);
    }

    // ============ إدارة العيادات ============
    getClinics() {
        return [...this.clinics];
    }

    getClinic(id) {
        return this.clinics.find(c => c.id === id);
    }

    async updateClinic(id, updates) {
        try {
            const isConnected = await this.checkAPIConnection();
            if (isConnected) {
                const updatedClinic = await this.putData(`/clinics/${id}`, updates);
                const index = this.clinics.findIndex(c => c.id === id);
                if (index !== -1) {
                    this.clinics[index] = { ...this.clinics[index], ...updatedClinic, updatedAt: new Date().toISOString() };
                    this.saveToLocalStorage();
                }
                return updatedClinic;
            } else {
                return this.updateClinicLocal(id, updates);
            }
        } catch (error) {
            console.error('❌ خطأ في تحديث العيادة:', error);
            return this.updateClinicLocal(id, updates);
        }
    }

    updateClinicLocal(id, updates) {
        const index = this.clinics.findIndex(c => c.id === id);
        if (index !== -1) {
            this.clinics[index] = { 
                ...this.clinics[index], 
                ...updates, 
                updatedAt: new Date().toISOString() 
            };
            this.saveToLocalStorage();
            return this.clinics[index];
        }
        return null;
    }

    async deleteClinic(id) {
        try {
            const isConnected = await this.checkAPIConnection();
            if (isConnected) {
                await this.deleteData(`/clinics/${id}`);
            }
            
            const index = this.clinics.findIndex(c => c.id === id);
            if (index !== -1) {
                this.clinics.splice(index, 1);
                this.saveToLocalStorage();
                return { success: true, message: "تم حذف العيادة بنجاح" };
            }
            
            return { success: false, error: "العيادة غير موجودة" };
        } catch (error) {
            console.error('❌ خطأ في حذف العيادة:', error);
            return { success: false, error: "حدث خطأ أثناء حذف العيادة" };
        }
    }

    // ============ إدارة الحجوزات ============
    getAppointments() {
        return [...this.appointments];
    }

    getTodayAppointments() {
        const today = new Date().toISOString().split('T')[0];
        return this.appointments.filter(a => a.appointmentDate === today);
    }

    // ============ الإحصائيات ============
    getStats() {
        return {
            totalPatients: this.patients.length,
            totalDoctors: this.doctors.length,
            totalClinics: this.clinics.length,
            totalAppointments: this.appointments.length,
            todayAppointments: this.getTodayAppointments().length,
            todayRevenue: this.getTodayAppointments().reduce((sum, a) => sum + (a.fee || 0), 0),
            activePatients: this.patients.filter(p => p.status === 'active').length,
            availableDoctors: this.doctors.filter(d => d.status === 'available').length,
            activeClinics: this.clinics.filter(c => c.status === 'active').length
        };
    }

    // ============ أدوات مساعدة ============
    generateId() {
        return Math.max(0, ...this.patients.map(p => p.id), ...this.doctors.map(d => d.id), ...this.clinics.map(c => c.id)) + 1;
    }

    async syncWithAPI() {
        console.log('🔄 مزامنة البيانات مع API...');
        try {
            const isConnected = await this.checkAPIConnection();
            if (isConnected) {
                await this.loadFromAPI();
                return { success: true, message: "تمت المزامنة بنجاح" };
            } else {
                return { success: false, message: "API غير متصل" };
            }
        } catch (error) {
            console.error('❌ خطأ في المزامنة:', error);
            return { success: false, message: "فشلت المزامنة" };
        }
    }
}

// إنشاء نسخة عامة من DataManager
if (!window.dataManager) {
    window.dataManager = new DataManager();
    
    // جعل syncWithAPI متاحاً عالمياً
    window.syncData = function() {
        return dataManager.syncWithAPI();
    };
    
    console.log('🎉 DataManager جاهز للعمل!');
}