// server.js - كامل بدون بيانات تجريبية
const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const app = express();
app.use(cors());
app.use(express.json());

// ✅ تحقق من وجود مجلد public
const publicPath = path.join(__dirname, 'public');
if (!fs.existsSync(publicPath)) {
    console.error('❌ مجلد public غير موجود!');
    process.exit(1);
}

// ✅ تعيين مجلد public للملفات الثابتة
app.use(express.static(publicPath));

// ✅ مسارات محددة للصفحات الرئيسية
app.get('/', (req, res) => {
    res.sendFile(path.join(publicPath, 'index.html'));
});

app.get('/dashboard.html', (req, res) => {
    res.sendFile(path.join(publicPath, 'dashboard.html'));
});

app.get('/all-bookings.html', (req, res) => {
    res.sendFile(path.join(publicPath, 'all-bookings.html'));
});

// ✅ مسار لجميع ملفات HTML
app.get('/*.html', (req, res) => {
    const fileName = req.path.split('/').pop();
    const filePath = path.join(publicPath, fileName);
    
    if (fs.existsSync(filePath)) {
        res.sendFile(filePath);
    } else {
        res.status(404).send(`الصفحة غير موجودة`);
    }
});

// الاتصال بقاعدة البيانات MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '12345',
    database: 'clinic_management',
    port: 3306,
    connectTimeout: 10000
});

db.connect((err) => {
    if (err) {
        console.error('❌ خطأ في الاتصال بقاعدة البيانات:', err.message);
        createDatabaseIfNotExists();
    } else {
        console.log('✅ تم الاتصال بقاعدة البيانات بنجاح');
        checkAndCreateTables();
    }
});

function createDatabaseIfNotExists() {
    const tempConnection = mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: '12345'
    });
    
    tempConnection.connect((err) => {
        if (err) {
            console.error('❌ لا يمكن الاتصال بـ MySQL');
            return;
        }
        
        tempConnection.query('CREATE DATABASE IF NOT EXISTS clinic_management', (err) => {
            if (err) {
                console.error('❌ خطأ في إنشاء قاعدة البيانات:', err.message);
            } else {
                console.log('✅ قاعدة البيانات جاهزة');
                tempConnection.end();
                
                db.changeUser({database: 'clinic_management'}, (err) => {
                    if (err) {
                        console.error('❌ خطأ في تغيير قاعدة البيانات:', err.message);
                    } else {
                        console.log('✅ تم الاتصال بقاعدة البيانات clinic_management');
                        checkAndCreateTables();
                    }
                });
            }
        });
    });
}

function checkAndCreateTables() {
    console.log('🔍 جاري إنشاء الجداول...');
    
    const tables = [
        `CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(100) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            full_name VARCHAR(255) NOT NULL,
            role ENUM('admin', 'doctor', 'receptionist', 'patient') DEFAULT 'receptionist',
            email VARCHAR(255),
            phone VARCHAR(20),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )`,
        
        `CREATE TABLE IF NOT EXISTS doctors (
            id INT AUTO_INCREMENT PRIMARY KEY,
            full_name VARCHAR(255) NOT NULL,
            specialty VARCHAR(255),
            phone VARCHAR(20),
            email VARCHAR(255),
            address TEXT,
            fee DECIMAL(10, 2) DEFAULT 100.00,
            status ENUM('active', 'inactive') DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )`,
        
        `CREATE TABLE IF NOT EXISTS patients (
            id INT AUTO_INCREMENT PRIMARY KEY,
            full_name VARCHAR(255) NOT NULL,
            age INT,
            gender ENUM('male', 'female'),
            phone VARCHAR(20),
            email VARCHAR(255),
            address TEXT,
            medical_history TEXT,
            status ENUM('active', 'inactive') DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )`,
        
        `CREATE TABLE IF NOT EXISTS clinics (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            type VARCHAR(100),
            doctor_id INT,
            floor VARCHAR(50),
            room VARCHAR(50),
            capacity INT DEFAULT 20,
            opening_time TIME DEFAULT '09:00:00',
            closing_time TIME DEFAULT '17:00:00',
            phone VARCHAR(20),
            email VARCHAR(255),
            description TEXT,
            color VARCHAR(10) DEFAULT '#2563eb',
            status ENUM('active', 'inactive', 'maintenance') DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )`,
        
        `CREATE TABLE IF NOT EXISTS appointments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            patient_id INT NOT NULL,
            doctor_id INT NOT NULL,
            clinic_id INT,
            appointment_date DATE NOT NULL,
            appointment_time TIME NOT NULL,
            status ENUM('pending', 'confirmed', 'completed', 'cancelled') DEFAULT 'pending',
            fee DECIMAL(10, 2) DEFAULT 0.00,
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )`
    ];
    
    tables.forEach((sql, index) => {
        db.query(sql, (err) => {
            if (err) {
                console.error(`❌ خطأ في إنشاء الجدول ${index + 1}:`, err.message);
            } else {
                console.log(`✅ الجدول ${index + 1} جاهز`);
            }
        });
    });
}

// ==================== API Routes ====================

// 1. إحصائيات لوحة التحكم
app.get('/api/dashboard/stats', (req, res) => {
    console.log('📊 طلب إحصائيات لوحة التحكم');
    
    const queries = {
        totalUsers: 'SELECT COUNT(*) as count FROM users WHERE role IN ("admin", "receptionist")',
        totalDoctors: 'SELECT COUNT(*) as count FROM doctors WHERE status = "active"',
        totalPatients: 'SELECT COUNT(*) as count FROM patients WHERE status = "active"',
        todayAppointments: 'SELECT COUNT(*) as count FROM appointments WHERE DATE(appointment_date) = CURDATE() AND status != "cancelled"',
        todayRevenue: 'SELECT COALESCE(SUM(fee), 0) as total FROM appointments WHERE DATE(appointment_date) = CURDATE() AND status = "completed"'
    };
    
    const results = {};
    let completedQueries = 0;
    const totalQueries = Object.keys(queries).length;
    
    Object.entries(queries).forEach(([key, query]) => {
        db.query(query, (err, result) => {
            if (err) {
                console.error(`❌ خطأ في ${key}:`, err.message);
                results[key] = 0;
            } else {
                results[key] = key === 'todayRevenue' ? result[0].total : result[0].count;
            }
            
            completedQueries++;
            if (completedQueries === totalQueries) {
                console.log('✅ الإحصائيات:', results);
                res.json(results);
            }
        });
    });
});

// 2. إحصائيات الحجوزات
app.get('/api/appointments/stats', (req, res) => {
    console.log('📊 طلب إحصائيات الحجوزات');
    
    const queries = {
        totalAppointments: 'SELECT COUNT(*) as count FROM appointments',
        completedAppointments: 'SELECT COUNT(*) as count FROM appointments WHERE status = "completed"',
        pendingAppointments: 'SELECT COUNT(*) as count FROM appointments WHERE status = "pending"',
        cancelledAppointments: 'SELECT COUNT(*) as count FROM appointments WHERE status = "cancelled"',
        totalRevenue: 'SELECT COALESCE(SUM(fee), 0) as total FROM appointments WHERE status = "completed"',
        todayAppointments: 'SELECT COUNT(*) as count FROM appointments WHERE DATE(appointment_date) = CURDATE()',
        thisMonthAppointments: 'SELECT COUNT(*) as count FROM appointments WHERE MONTH(appointment_date) = MONTH(CURDATE()) AND YEAR(appointment_date) = YEAR(CURDATE())'
    };
    
    const results = {};
    let completedQueries = 0;
    const totalQueries = Object.keys(queries).length;
    
    Object.entries(queries).forEach(([key, query]) => {
        db.query(query, (err, result) => {
            if (err) {
                console.error(`❌ خطأ في ${key}:`, err.message);
                results[key] = 0;
            } else {
                results[key] = key === 'totalRevenue' ? result[0].total : result[0].count;
            }
            
            completedQueries++;
            if (completedQueries === totalQueries) {
                console.log('✅ إحصائيات الحجوزات:', results);
                res.json(results);
            }
        });
    });
});

// 3. مواعيد اليوم
app.get('/api/appointments/today', (req, res) => {
    console.log('📅 طلب مواعيد اليوم');
    
    const query = `
        SELECT 
            a.id as appointment_id,
            p.full_name as patient_name,
            d.full_name as doctor_name,
            DATE_FORMAT(a.appointment_time, '%H:%i') as appointment_time,
            a.status,
            a.fee
        FROM appointments a
        LEFT JOIN patients p ON a.patient_id = p.id
        LEFT JOIN doctors d ON a.doctor_id = d.id
        WHERE DATE(a.appointment_date) = CURDATE()
        ORDER BY a.appointment_time
        LIMIT 10
    `;
    
    db.query(query, (err, results) => {
        if (err) {
            console.error('❌ خطأ في جلب المواعيد:', err.message);
            res.status(500).json({ error: 'خطأ في الخادم' });
        } else {
            console.log(`✅ تم إرسال ${results.length} موعد`);
            res.json(results);
        }
    });
});

// 4. جميع الحجوزات مع فلترة
app.get('/api/appointments', (req, res) => {
    console.log('📋 طلب جميع الحجوزات');
    
    const { status, date, doctor_id, patient_id, page = 1, limit = 20 } = req.query;
    
    let whereClauses = [];
    let queryParams = [];
    
    if (status) {
        whereClauses.push('a.status = ?');
        queryParams.push(status);
    }
    
    if (date) {
        whereClauses.push('DATE(a.appointment_date) = ?');
        queryParams.push(date);
    }
    
    if (doctor_id) {
        whereClauses.push('a.doctor_id = ?');
        queryParams.push(doctor_id);
    }
    
    if (patient_id) {
        whereClauses.push('a.patient_id = ?');
        queryParams.push(patient_id);
    }
    
    const whereClause = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : '';
    const offset = (parseInt(page) - 1) * parseInt(limit);
    
    const query = `
        SELECT 
            a.id,
            a.appointment_date,
            DATE_FORMAT(a.appointment_time, '%H:%i') as appointment_time,
            a.status,
            a.fee,
            a.notes,
            p.full_name as patient_name,
            p.phone as patient_phone,
            d.full_name as doctor_name,
            d.specialty as doctor_specialty,
            c.name as clinic_name
        FROM appointments a
        LEFT JOIN patients p ON a.patient_id = p.id
        LEFT JOIN doctors d ON a.doctor_id = d.id
        LEFT JOIN clinics c ON a.clinic_id = c.id
        ${whereClause}
        ORDER BY a.appointment_date DESC, a.appointment_time DESC
        LIMIT ? OFFSET ?
    `;
    
    const countQuery = `
        SELECT COUNT(*) as total
        FROM appointments a
        ${whereClause}
    `;
    
    // جلب العدد الإجمالي
    db.query(countQuery, queryParams, (err, countResult) => {
        if (err) {
            console.error('❌ خطأ في عد الحجوزات:', err.message);
            res.status(500).json({ error: 'خطأ في الخادم' });
            return;
        }
        
        const total = countResult[0].total;
        const totalPages = Math.ceil(total / limit);
        
        // جلب البيانات
        db.query(query, [...queryParams, parseInt(limit), offset], (err, results) => {
            if (err) {
                console.error('❌ خطأ في جلب الحجوزات:', err.message);
                res.status(500).json({ error: 'خطأ في الخادم' });
            } else {
                console.log(`✅ تم إرسال ${results.length} حجز`);
                res.json({
                    appointments: results,
                    pagination: {
                        page: parseInt(page),
                        limit: parseInt(limit),
                        total,
                        totalPages
                    }
                });
            }
        });
    });
});

// 5. الحصول على حجز معين
app.get('/api/appointments/:id', (req, res) => {
    const { id } = req.params;
    
    const query = `
        SELECT 
            a.*,
            p.full_name as patient_name,
            p.age as patient_age,
            p.gender as patient_gender,
            p.phone as patient_phone,
            d.full_name as doctor_name,
            d.specialty as doctor_specialty,
            d.fee as doctor_fee,
            c.name as clinic_name,
            c.floor as clinic_floor,
            c.room as clinic_room
        FROM appointments a
        LEFT JOIN patients p ON a.patient_id = p.id
        LEFT JOIN doctors d ON a.doctor_id = d.id
        LEFT JOIN clinics c ON a.clinic_id = c.id
        WHERE a.id = ?
    `;
    
    db.query(query, [id], (err, results) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else if (results.length === 0) {
            res.status(404).json({ error: 'الحجز غير موجود' });
        } else {
            res.json(results[0]);
        }
    });
});

// 6. إنشاء حجز جديد
app.post('/api/appointments', (req, res) => {
    const { patient_id, doctor_id, clinic_id, appointment_date, appointment_time, fee, notes, status } = req.body;
    
    if (!patient_id || !doctor_id || !appointment_date || !appointment_time) {
        return res.status(400).json({ error: 'بيانات ناقصة' });
    }
    
    const query = `
        INSERT INTO appointments 
        (patient_id, doctor_id, clinic_id, appointment_date, appointment_time, fee, notes, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;
    
    db.query(query, [patient_id, doctor_id, clinic_id, appointment_date, appointment_time, fee || 0, notes || '', status || 'pending'], 
        (err, result) => {
            if (err) {
                console.error('❌ خطأ في إضافة الحجز:', err.message);
                res.status(500).json({ error: err.message });
            } else {
                console.log('✅ تم إضافة حجز جديد:', result.insertId);
                res.json({ 
                    success: true, 
                    id: result.insertId,
                    message: 'تم إضافة الحجز بنجاح'
                });
            }
        }
    );
});

// 7. تحديث حجز
app.put('/api/appointments/:id', (req, res) => {
    const { id } = req.params;
    const appointmentData = req.body;
    
    const query = 'UPDATE appointments SET ? WHERE id = ?';
    
    db.query(query, [appointmentData, id], (err, result) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else if (result.affectedRows === 0) {
            res.status(404).json({ error: 'الحجز غير موجود' });
        } else {
            res.json({ success: true, message: 'تم تحديث الحجز' });
        }
    });
});

// 8. تحديث حالة الحجز
app.put('/api/appointments/:id/status', (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    
    if (!['pending', 'confirmed', 'completed', 'cancelled'].includes(status)) {
        return res.status(400).json({ error: 'حالة غير صالحة' });
    }
    
    db.query('UPDATE appointments SET status = ? WHERE id = ?', [status, id], (err, result) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else if (result.affectedRows === 0) {
            res.status(404).json({ error: 'الحجز غير موجود' });
        } else {
            res.json({ success: true, message: `تم تحديث الحالة إلى ${status}` });
        }
    });
});

// 9. حذف حجز
app.delete('/api/appointments/:id', (req, res) => {
    const { id } = req.params;
    
    db.query('DELETE FROM appointments WHERE id = ?', [id], (err, result) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else if (result.affectedRows === 0) {
            res.status(404).json({ error: 'الحجز غير موجود' });
        } else {
            res.json({ success: true, message: 'تم حذف الحجز' });
        }
    });
});

// 10. قائمة العيادات
app.get('/api/clinics', (req, res) => {
    const query = `
        SELECT c.*, d.full_name as doctor_name 
        FROM clinics c
        LEFT JOIN doctors d ON c.doctor_id = d.id
        ORDER BY c.name
    `;
    
    db.query(query, (err, results) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json(results);
        }
    });
});

// 11. قائمة الأطباء
app.get('/api/doctors', (req, res) => {
    const query = 'SELECT * FROM doctors ORDER BY full_name';
    db.query(query, (err, results) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json(results);
        }
    });
});

// 12. قائمة المرضى
app.get('/api/patients', (req, res) => {
    const query = 'SELECT * FROM patients ORDER BY full_name';
    db.query(query, (err, results) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json(results);
        }
    });
});

// 13. الحصول على مواعيد الطبيب
app.get('/api/doctors/:id/appointments', (req, res) => {
    const { id } = req.params;
    const { date } = req.query;
    
    let whereClause = 'WHERE a.doctor_id = ?';
    let queryParams = [id];
    
    if (date) {
        whereClause += ' AND DATE(a.appointment_date) = ?';
        queryParams.push(date);
    }
    
    const query = `
        SELECT 
            a.id,
            a.appointment_date,
            DATE_FORMAT(a.appointment_time, '%H:%i') as appointment_time,
            a.status,
            p.full_name as patient_name
        FROM appointments a
        JOIN patients p ON a.patient_id = p.id
        ${whereClause}
        ORDER BY a.appointment_date, a.appointment_time
    `;
    
    db.query(query, queryParams, (err, results) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json(results);
        }
    });
});

// 14. تسجيل الدخول
app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    
    const query = 'SELECT id, username, full_name, role FROM users WHERE username = ? AND password = ?';
    
    db.query(query, [username, password], (err, results) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else if (results.length === 0) {
            res.status(401).json({ error: 'بيانات الدخول غير صحيحة' });
        } else {
            res.json({ success: true, user: results[0] });
        }
    });
});

// 15. إنشاء مستخدم جديد (للمسؤول فقط)
app.post('/api/users', (req, res) => {
    const { username, password, full_name, role, email, phone } = req.body;
    
    if (!username || !password || !full_name || !role) {
        return res.status(400).json({ error: 'بيانات ناقصة' });
    }
    
    const query = 'INSERT INTO users (username, password, full_name, role, email, phone) VALUES (?, ?, ?, ?, ?, ?)';
    
    db.query(query, [username, password, full_name, role, email || null, phone || null], (err, result) => {
        if (err) {
            if (err.code === 'ER_DUP_ENTRY') {
                res.status(400).json({ error: 'اسم المستخدم موجود بالفعل' });
            } else {
                res.status(500).json({ error: err.message });
            }
        } else {
            res.json({ success: true, id: result.insertId, message: 'تم إنشاء المستخدم بنجاح' });
        }
    });
});

// صفحة 404 لـ API
app.use('/api/*', (req, res) => {
    res.status(404).json({ error: 'API غير موجود' });
});

// تشغيل السيرفر
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`🚀 السيرفر يعمل على: http://localhost:${PORT}`);
    console.log(`📊 لوحة التحكم: http://localhost:${PORT}/dashboard.html`);
    console.log(`📋 الحجوزات: http://localhost:${PORT}/all-bookings.html`);
    console.log(`🏥 الصفحة الرئيسية: http://localhost:${PORT}`);
    console.log('📝 قاعدة البيانات: فارغة بدون بيانات تجريبية');
});