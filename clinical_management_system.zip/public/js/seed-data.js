// seed-data.js
const { getDatabase } = require('./database');

async function seedDatabase() {
    const db = getDatabase();
    
    try {
        // التحقق من الاتصال
        await db.checkConnection();
        console.log('✅ Connected to database');
        
        // إضافة بيانات المستخدمين
        console.log('📝 Adding users...');
        // ... كود إضافة البيانات
        
        console.log('🎉 Database seeded successfully!');
    } catch (error) {
        console.error('❌ Error seeding database:', error);
    }
}

seedDatabase();