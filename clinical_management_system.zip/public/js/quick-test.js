const mysql = require('mysql2/promise');

console.log('🔍 اختبار اتصال قاعدة البيانات...');

async function testConnection() {
    try {
        // جرب كلمة المرور 12345
        const connection = await mysql.createConnection({
            host: 'localhost',
            user: 'root',
            password: '12345',  // كلمة المرور التي قلتها
            database: 'clinic_management',
            port: 3306
        });

        console.log('✅ ✅ ✅ نجح الاتصال بقاعدة البيانات!');
        
        // عرض الجداول
        const [tables] = await connection.execute('SHOW TABLES');
        console.log(`📊 عدد الجداول في قاعدة البيانات: ${tables.length}`);
        
        tables.forEach(table => {
            console.log(`   - ${table.Tables_in_clinic_management}`);
        });
        
        // عرض عدد المرضى
        const [patients] = await connection.execute('SELECT COUNT(*) as count FROM patients');
        console.log(`👥 عدد المرضى: ${patients[0].count}`);
        
        // عرض عدد الأطباء
        const [doctors] = await connection.execute('SELECT COUNT(*) as count FROM doctors');
        console.log(`👨‍⚕️ عدد الأطباء: ${doctors[0].count}`);
        
        connection.end();
        console.log('\n🎉 كل شيء يعمل بشكل صحيح!');
        return true;
        
    } catch (error) {
        console.log('❌ ❌ ❌ فشل الاتصال بقاعدة البيانات');
        console.log(`🔧 الخطأ: ${error.code}`);
        console.log(`📝 الرسالة: ${error.message}`);
        
        // إذا كانت كلمة المرور خطأ، جرب أخرى
        console.log('\n💡 جاري تجربة كلمات مرور أخرى...');
        
        const passwords = ['', 'root', 'password', '123456', 'mysql'];
        for (const pwd of passwords) {
            try {
                const conn = await mysql.createConnection({
                    host: 'localhost',
                    user: 'root',
                    password: pwd,
                    database: 'clinic_management'
                });
                console.log(`✅ نجحت كلمة المرور: "${pwd || '(فارغة)'}"`);
                conn.end();
                return pwd;
            } catch (e) {
                // تجاهل الخطأ
            }
        }
        
        console.log('⚠️ لم تنجح أي كلمة مرور.');
        return false;
    }
}

testConnection();