const express = require('express');
const cors = require('cors');
const { getDatabase } = require('./database');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
app.get('/api/health', async (req, res) => {
    try {
        const db = getDatabase();
        const connected = await db.checkConnection();

        res.json({
            status: 'OK',
            database: connected ? 'connected' : 'disconnected',
            message: connected ? '✅ النظام يعمل بشكل طبيعي' : '⚠️ مشكلة في قاعدة البيانات',
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// صفحة رئيسية بسيطة
app.get('/', (req, res) => {
    res.send(`
        <html>
        <head><title>نظام العيادات</title></head>
        <body style="font-family: Arial; padding: 20px;">
            <h1>نظام إدارة العيادات clinic management </h1>
            <p>الخادم يعمل على المنفذ ${PORT}</p>
            <h2>واجهات API:</h2>
            <ul>
                <li><a href="/api/health">/api/health</a> - حالة النظام</li>
                <li><a href="/api/patients">/api/patients</a> - المرضى</li>
                <li><a href="/api/doctors">/api/doctors</a> - الأطباء</li>
                <li><a href="/api/clinics">/api/clinics</a> - العيادات</li>
            </ul>
        </body>
        </html>
    `);
});

app.get('/api/dashboard/stats', async (req, res) => {
    try {
        const db = getDatabase();
        const stats = await db.getDashboardStats();
        res.json(stats);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/patients', async (req, res) => {
    try {
        const db = getDatabase();
        const patients = await db.getPatients();
        res.json(patients);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/doctors', async (req, res) => {
    try {
        const db = getDatabase();
        const doctors = await db.getDoctors();
        res.json(doctors);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/clinics', async (req, res) => {
    try {
        const db = getDatabase();
        const clinics = await db.getClinics();
        res.json(clinics);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/appointments', async (req, res) => {
    try {
        const { date } = req.query;
        const db = getDatabase();
        const appointments = await db.getAppointments(date);
        res.json(appointments);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.post('/api/appointments', async (req, res) => {
    try {
        const db = getDatabase();
        const result = await db.createAppointment(req.body);

        if (result.success) {
            res.status(201).json({
                success: true,
                message: '✅ تم إنشاء الحجز بنجاح',
                appointment_id: result.appointment_id,
                appointment_code: result.appointment_code
            });
        } else {
            res.status(400).json({
                success: false,
                message: result.message
            });
        }
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Static files
app.use(express.static('public'));

// Start server
app.listen(PORT, () => {
    console.log(`🚀 Server running at http://localhost:${PORT}`);
    console.log(`📊 Database: ${process.env.DB_NAME}`);
    console.log(`📁 API Endpoints:`);
    console.log(`   http://localhost:${PORT}/api/health`);
    console.log(`   http://localhost:${PORT}/api/patients`);
    console.log(`   http://localhost:${PORT}/api/doctors`);
    console.log(`   http://localhost:${PORT}/api/appointments`);
    console.log(`📌 اضغط Ctrl+C لإيقاف الخادم`);
});