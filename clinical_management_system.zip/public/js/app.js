﻿// ============================================
// نظام إدارة العيادات clinic management  - ملف JavaScript الرئيسي
// التواصل مع API والتحكم بالواجهة
// ============================================

// إعدادات الاتصال الأساسية
const API_BASE_URL = 'http://localhost:3000/api';
const TOKEN_KEY = 'clinic_auth_token';

// دالة رئيسية لجلب البيانات من API
async function fetchFromAPI(endpoint, options = {}) {
    try {
        const url = `${API_BASE_URL}${endpoint}`;
        console.log(`🌐 إرسال طلب ${options.method || 'GET'} إلى: ${url}`);
        
        const token = localStorage.getItem(TOKEN_KEY);
        const defaultHeaders = {
            'Content-Type': 'application/json',
        };

        if (token) {
            defaultHeaders['Authorization'] = `Bearer ${token}`;
        }

        const response = await fetch(url, {
            headers: { ...defaultHeaders, ...options.headers },
            ...options
        });

        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.message || `خطأ في الخادم: ${response.status}`);
        }

        return await response.json();
    } catch (error) {
        console.error('❌ خطأ في الاتصال بالخادم:', error.message);
        showNotification(`❌ ${error.message || 'خطأ في الاتصال بالخادم'}`, 'error');
        throw error;
    }
}

// ============================================
// 📊 دوال تحميل البيانات
// ============================================

// جلب جميع العيادات
async function loadClinics() {
    try {
        const data = await fetchFromAPI('/clinics');
        return data;
    } catch (error) {
        console.log('⚠️ استخدام بيانات تجريبية للعيادات');
        return getMockClinics();
    }
}

// جلب عيادة واحدة
async function loadClinic(clinicId) {
    try {
        const data = await fetchFromAPI(`/clinics/${clinicId}`);
        return data;
    } catch (error) {
        console.log('⚠️ استخدام بيانات تجريبية للعيادة');
        return getMockClinic(clinicId);
    }
}

// إضافة عيادة جديدة
async function addClinic(clinicData) {
    try {
        const response = await fetchFromAPI('/clinics', {
            method: 'POST',
            body: JSON.stringify(clinicData)
        });
        
        showNotification('✅ تم إضافة العيادة بنجاح', 'success');
        return response;
    } catch (error) {
        showNotification(`❌ ${error.message || 'فشل في إضافة العيادة'}`, 'error');
        throw error;
    }
}

// تحديث بيانات العيادة
async function updateClinic(clinicId, clinicData) {
    try {
        const response = await fetchFromAPI(`/clinics/${clinicId}`, {
            method: 'PUT',
            body: JSON.stringify(clinicData)
        });
        
        showNotification('✅ تم تحديث العيادة بنجاح', 'success');
        return response;
    } catch (error) {
        showNotification(`❌ ${error.message || 'فشل في تحديث العيادة'}`, 'error');
        throw error;
    }
}

// حذف العيادة
async function deleteClinic(clinicId) {
    try {
        const response = await fetchFromAPI(`/clinics/${clinicId}`, {
            method: 'DELETE'
        });
        
        showNotification('✅ تم حذف العيادة بنجاح', 'success');
        return response;
    } catch (error) {
        showNotification(`❌ ${error.message || 'فشل في حذف العيادة'}`, 'error');
        throw error;
    }
}

// ============================================
// 🎨 دوال عرض البيانات
// ============================================

// عرض العيادات في البطاقات
function renderClinicsCards(clinics) {
    const container = document.querySelector('.clinics-grid');
    if (!container) return;
    
    container.innerHTML = '';
    
    if (clinics.length === 0) {
        container.innerHTML = `
            <div style="grid-column: 1/-1; text-align: center; padding: 40px; color: #6b7280;">
                <i class="fas fa-clinic-medical" style="font-size: 48px; margin-bottom: 20px;"></i>
                <h3>لا توجد عيادات</h3>
                <p>اضغط على زر "إضافة عيادة جديدة" لبدء إضافة العيادات</p>
            </div>
        `;
        return;
    }
    
    const clinicTypes = {
        'general': { icon: 'fa-stethoscope', color: 'general', label: 'عامة' },
        'pediatric': { icon: 'fa-baby', color: 'pediatric', label: 'أطفال' },
        'cardio': { icon: 'fa-heartbeat', color: 'cardio', label: 'قلب' },
        'ortho': { icon: 'fa-bone', color: 'ortho', label: 'عظام' },
        'surgery': { icon: 'fa-syringe', color: 'surgery', label: 'جراحة' },
        'dental': { icon: 'fa-tooth', color: 'dental', label: 'أسنان' }
    };
    
    clinics.forEach(clinic => {
        const type = clinicTypes[clinic.clinic_type] || clinicTypes.general;
        
        const card = document.createElement('div');
        card.className = 'clinic-card';
        card.innerHTML = `
            <div class="clinic-header">
                <div class="clinic-icon ${type.color}">
                    <i class="fas ${type.icon}"></i>
                </div>
                <div class="clinic-info">
                    <h3>${clinic.clinic_name}</h3>
                    <p>${clinic.floor_number || ''} ${clinic.room_number ? `- غرفة ${clinic.room_number}` : ''}</p>
                </div>
            </div>
            <div class="clinic-body">
                <ul class="clinic-details">
                    <li><i class="fas fa-tag"></i> ${type.label}</li>
                    <li><i class="fas fa-clock"></i> ${formatTime(clinic.opening_time)} - ${formatTime(clinic.closing_time)}</li>
                    <li><i class="fas fa-users"></i> سعة: ${clinic.capacity} مريض/يوم</li>
                    <li><i class="fas fa-phone"></i> داخلي: ${clinic.phone_extension || '---'}</li>
                </ul>
                <span class="clinic-status ${clinic.is_active ? 'status-active' : 'status-inactive'}">
                    ${clinic.is_active ? 'نشطة' : 'غير نشطة'}
                </span>
                <div class="clinic-actions">
                    <button class="btn-sm btn-outline" onclick="editClinic(${clinic.clinic_id})">
                        <i class="fas fa-edit"></i> تعديل
                    </button>
                    <button class="btn-sm btn-primary" onclick="viewClinicAppointments(${clinic.clinic_id})">
                        <i class="fas fa-calendar-check"></i> الحجوزات
                    </button>
                    <button class="btn-sm btn-danger" onclick="toggleClinicStatus(${clinic.clinic_id})">
                        <i class="fas fa-power-off"></i> ${clinic.is_active ? 'إيقاف' : 'تفعيل'}
                    </button>
                </div>
            </div>
        `;
        container.appendChild(card);
    });
}

// ============================================
// 🔔 نظام الإشعارات
// ============================================

function showNotification(message, type = 'info') {
    // إزالة أي إشعارات سابقة
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notif => notif.remove());
    
    // إنشاء الإشعار الجديد
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="notification-icon ${getNotificationIcon(type)}"></i>
            <span>${message}</span>
        </div>
        <button class="notification-close" onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    document.body.appendChild(notification);
    
    // إخفاء الإشعار تلقائياً بعد 5 ثوانٍ
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 5000);
}

function getNotificationIcon(type) {
    const icons = {
        'success': 'fas fa-check-circle',
        'error': 'fas fa-exclamation-circle',
        'warning': 'fas fa-exclamation-triangle',
        'info': 'fas fa-info-circle'
    };
    return icons[type] || icons.info;
}

// إضافة أنماط الإشعارات
function initNotificationStyles() {
    if (!document.querySelector('#notification-styles')) {
        const style = document.createElement('style');
        style.id = 'notification-styles';
        style.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                min-width: 300px;
                max-width: 400px;
                padding: 15px 20px;
                border-radius: 10px;
                color: white;
                font-weight: 500;
                z-index: 9999;
                animation: slideIn 0.3s ease;
                box-shadow: 0 5px 15px rgba(0,0,0,0.1);
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            
            .notification-content {
                display: flex;
                align-items: center;
                gap: 10px;
                flex: 1;
            }
            
            .notification-icon {
                font-size: 18px;
            }
            
            .notification-close {
                background: none;
                border: none;
                color: white;
                cursor: pointer;
                opacity: 0.7;
                transition: opacity 0.3s;
                padding: 5px;
            }
            
            .notification-close:hover {
                opacity: 1;
            }
            
            .notification-success {
                background: linear-gradient(135deg, #10b981 0%, #059669 100%);
                border-right: 4px solid #065f46;
            }
            
            .notification-error {
                background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
                border-right: 4px solid #991b1b;
            }
            
            .notification-warning {
                background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
                border-right: 4px solid #92400e;
            }
            
            .notification-info {
                background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
                border-right: 4px solid #1e40af;
            }
            
            @keyframes slideIn {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
        `;
        document.head.appendChild(style);
    }
}

// ============================================
// 🛠️ دوال مساعدة
// ============================================

function formatTime(timeString) {
    if (!timeString) return '---';
    return timeString.substring(0, 5);
}

// ============================================
// 📋 بيانات تجريبية
// ============================================

function getMockClinics() {
    return [
        {
            clinic_id: 1,
            clinic_name: 'العيادة العامة',
            clinic_type: 'general',
            floor_number: 'الطابق الأول',
            room_number: '101',
            phone_extension: '101',
            capacity: 30,
            opening_time: '09:00:00',
            closing_time: '17:00:00',
            is_active: true
        },
        {
            clinic_id: 2,
            clinic_name: 'عيادة الأطفال',
            clinic_type: 'pediatric',
            floor_number: 'الطابق الثاني',
            room_number: '201',
            phone_extension: '201',
            capacity: 25,
            opening_time: '10:00:00',
            closing_time: '18:00:00',
            is_active: true
        }
    ];
}

function getMockClinic(clinicId) {
    return {
        clinic_id: clinicId,
        clinic_name: 'العيادة العامة',
        clinic_type: 'general',
        floor_number: 'الطابق الأول',
        room_number: '101',
        phone_extension: '101',
        capacity: 30,
        opening_time: '09:00:00',
        closing_time: '17:00:00',
        notes: '',
        is_active: true
    };
}

// ============================================
// 🚀 دوال الواجهة العامة
// ============================================

// تعديل العيادة
function editClinic(clinicId) {
    console.log(`✏️ تعديل العيادة ID: ${clinicId}`);
    window.location.href = `clinic-edit.html?id=${clinicId}`;
}

// عرض حجوزات العيادة
function viewClinicAppointments(clinicId) {
    window.location.href = `all-bookings.html?clinic_id=${clinicId}`;
}

// تبديل حالة العيادة
async function toggleClinicStatus(clinicId) {
    try {
        const response = await fetchFromAPI(`/clinics/${clinicId}/toggle`, {
            method: 'PUT'
        });
        
        showNotification('✅ تم تغيير حالة العيادة بنجاح', 'success');
        setTimeout(() => location.reload(), 1000);
    } catch (error) {
        showNotification(`❌ ${error.message || 'فشل في تغيير الحالة'}`, 'error');
    }
}

// ============================================
// 🌐 تهيئة النظام
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    // تهيئة أنماط الإشعارات
    initNotificationStyles();
    
    // تحميل البيانات حسب الصفحة
    const path = window.location.pathname;
    
    if (path.includes('clinics.html')) {
        loadClinics().then(clinics => {
            renderClinicsCards(clinics);
        });
    }
});

// تصدير الدوال للاستخدام العام
window.fetchFromAPI = fetchFromAPI;
window.loadClinics = loadClinics;
window.loadClinic = loadClinic;
window.addClinic = addClinic;
window.updateClinic = updateClinic;
window.deleteClinic = deleteClinic;
window.renderClinicsCards = renderClinicsCards;
window.showNotification = showNotification;
window.editClinic = editClinic;
window.viewClinicAppointments = viewClinicAppointments;
window.toggleClinicStatus = toggleClinicStatus;

console.log('✅ نظام clinic management  - ملف app.js جاهز للعمل!');