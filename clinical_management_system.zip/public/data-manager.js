// data-manager.js - نظام إدارة البيانات المركزي
class DataManager {
    constructor() {
        this.initStorage();
    }

    // 📁 تهيئة التخزين
    initStorage() {
        console.log('🔧 تهيئة نظام التخزين...');
        
        // تأكد من وجود جميع المفاتيح
        const storageKeys = [
            'clinic management _appointments',
            'clinic management _doctors',
            'clinic management _patients',
            'clinic management _clinics',
            'clinic management _settings'
        ];
        
        storageKeys.forEach(key => {
            if (!localStorage.getItem(key)) {
                localStorage.setItem(key, JSON.stringify([]));
                console.log(`✅ تم إنشاء ${key}`);
            }
        });
        
        // تحميل البيانات الافتراضية إذا كانت فارغة
        this.loadDefaultData();
    }

    // 📊 تحميل البيانات الافتراضية
    loadDefaultData() {
        // بيانات الأطباء الافتراضية
        if (this.getDoctors().length === 0) {
            console.log('📝 تحميل بيانات أطباء افتراضية...');
            const defaultDoctors = [
                {
                    id: 'D-1001',
                    fullName: 'د. محمود عبدالرحمن',
                    specialty: 'طب عام',
                    clinic: 'العيادة العامة',
                    phone: '+20 100 100 1001',
                    email: 'mahmoud@clinic.com',
                    qualifications: 'دكتوراه في الطب - جامعة القاهرة',
                    rating: 4.8,
                    patientsPerDay: 20,
                    status: 'active',
                    schedule: {
                        'الأحد - الأربعاء': '9:00 ص - 5:00 م',
                        'الخميس': '9:00 ص - 2:00 م'
                    },
                    appointments: 0,
                    joinedDate: '2023-01-15'
                },
                {
                    id: 'D-1002',
                    fullName: 'د. نادية فاروق',
                    specialty: 'أطفال',
                    clinic: 'عيادة الأطفال',
                    phone: '+20 100 100 1002',
                    email: 'nadia@clinic.com',
                    qualifications: 'ماجستير طب الأطفال - جامعة عين شمس',
                    rating: 4.9,
                    patientsPerDay: 15,
                    status: 'active',
                    schedule: {
                        'الإثنين - الخميس': '10:00 ص - 4:00 م',
                        'السبت': '10:00 ص - 2:00 م'
                    },
                    appointments: 0,
                    joinedDate: '2023-03-20'
                },
                {
                    id: 'D-1003',
                    fullName: 'د. هبة أحمد',
                    specialty: 'قلب',
                    clinic: 'عيادة القلب',
                    phone: '+20 100 100 1003',
                    email: 'heba@clinic.com',
                    qualifications: 'دكتوراه أمراض القلب - جامعة الأسكندرية',
                    rating: 4.7,
                    patientsPerDay: 12,
                    status: 'active',
                    schedule: {
                        'الأحد - الثلاثاء': '11:00 ص - 6:00 م',
                        'الأربعاء': '11:00 ص - 3:00 م'
                    },
                    appointments: 0,
                    joinedDate: '2023-02-10'
                },
                {
                    id: 'D-1004',
                    fullName: 'د. وسام طه',
                    specialty: 'عظام',
                    clinic: 'عيادة العظام',
                    phone: '+20 100 100 1004',
                    email: 'wesam@clinic.com',
                    qualifications: 'ماجستير جراحة العظام - جامعة أسيوط',
                    rating: 4.6,
                    patientsPerDay: 18,
                    status: 'active',
                    schedule: {
                        'الأحد - الخميس': '8:00 ص - 4:00 م'
                    },
                    appointments: 0,
                    joinedDate: '2023-04-05'
                }
            ];
            this.saveDoctors(defaultDoctors);
        }

        // بيانات المرضى الافتراضية
        if (this.getPatients().length === 0) {
            console.log('📝 تحميل بيانات مرضى افتراضية...');
            const defaultPatients = [
                {
                    id: 'P-1001',
                    fullName: 'أحمد محمد',
                    age: 35,
                    gender: 'ذكر',
                    phone: '+20 100 200 3001',
                    email: 'ahmed@example.com',
                    address: 'القاهرة - مصر الجديدة',
                    bloodType: 'O+',
                    allergies: 'لا توجد',
                    medicalHistory: [],
                    createdAt: new Date().toISOString()
                },
                {
                    id: 'P-1002',
                    fullName: 'سارة خالد',
                    age: 28,
                    gender: 'أنثى',
                    phone: '+20 100 200 3002',
                    email: 'sara@example.com',
                    address: 'الجيزة - الدقي',
                    bloodType: 'A+',
                    allergies: 'البنسلين',
                    medicalHistory: [],
                    createdAt: new Date().toISOString()
                },
                {
                    id: 'P-1003',
                    fullName: 'معتز علي',
                    age: 42,
                    gender: 'ذكر',
                    phone: '+20 100 200 3003',
                    email: 'moataz@example.com',
                    address: 'الإسكندرية - سموحة',
                    bloodType: 'B+',
                    allergies: 'لا توجد',
                    medicalHistory: [],
                    createdAt: new Date().toISOString()
                },
                {
                    id: 'P-1004',
                    fullName: 'نورا سعيد',
                    age: 31,
                    gender: 'أنثى',
                    phone: '+20 100 200 3004',
                    email: 'nora@example.com',
                    address: 'المنصورة - مدينة المنصورة',
                    bloodType: 'AB+',
                    allergies: 'المسكنات',
                    medicalHistory: [],
                    createdAt: new Date().toISOString()
                }
            ];
            this.savePatients(defaultPatients);
        }

        // بيانات الحجوزات الافتراضية
        if (this.getAppointments().length === 0) {
            console.log('📝 تحميل بيانات حجوزات افتراضية...');
            const today = new Date();
            const tomorrow = new Date(today);
            tomorrow.setDate(tomorrow.getDate() + 1);
            const dayAfterTomorrow = new Date(today);
            dayAfterTomorrow.setDate(dayAfterTomorrow.getDate() + 2);
            
            const defaultAppointments = [
                {
                    id: 'APT-2024-1001',
                    appointmentNumber: 'APT-2024-1001',
                    patientId: 'P-1001',
                    patientName: 'أحمد محمد',
                    doctorId: 'D-1001',
                    doctorName: 'د. محمود عبدالرحمن',
                    clinic: 'العيادة العامة',
                    type: 'استشارة أولية',
                    date: today.toISOString().split('T')[0],
                    time: '10:00 صباحاً',
                    timeValue: '10:00',
                    status: 'completed',
                    statusText: 'مكتمل',
                    fees: 165,
                    paid: true,
                    notes: 'كشف أولي - ضغط مرتفع',
                    createdAt: new Date().toISOString(),
                    day: this.getArabicDay(today.getDay())
                },
                {
                    id: 'APT-2024-1002',
                    appointmentNumber: 'APT-2024-1002',
                    patientId: 'P-1002',
                    patientName: 'سارة خالد',
                    doctorId: 'D-1002',
                    doctorName: 'د. نادية فاروق',
                    clinic: 'عيادة الأطفال',
                    type: 'متابعة',
                    date: tomorrow.toISOString().split('T')[0],
                    time: '11:30 صباحاً',
                    timeValue: '11:30',
                    status: 'confirmed',
                    statusText: 'مؤكد',
                    fees: 165,
                    paid: true,
                    notes: 'متابعة حالة الطفل بعد العلاج',
                    createdAt: new Date().toISOString(),
                    day: this.getArabicDay(tomorrow.getDay())
                },
                {
                    id: 'APT-2024-1003',
                    appointmentNumber: 'APT-2024-1003',
                    patientId: 'P-1003',
                    patientName: 'معتز علي',
                    doctorId: 'D-1003',
                    doctorName: 'د. هبة أحمد',
                    clinic: 'عيادة القلب',
                    type: 'فحص دوري',
                    date: dayAfterTomorrow.toISOString().split('T')[0],
                    time: '02:00 مساءً',
                    timeValue: '14:00',
                    status: 'pending',
                    statusText: 'قيد الانتظار',
                    fees: 200,
                    paid: false,
                    notes: 'فحص قلب شامل',
                    createdAt: new Date().toISOString(),
                    day: this.getArabicDay(dayAfterTomorrow.getDay())
                }
            ];
            this.saveAppointments(defaultAppointments);
        }

        console.log('✅ تم تحميل البيانات الافتراضية بنجاح');
    }

    // 🗃️ دوال الحصول على البيانات
    getAppointments() {
        try {
            const data = localStorage.getItem('clinic management _appointments');
            return data ? JSON.parse(data) : [];
        } catch (error) {
            console.error('❌ خطأ في قراءة الحجوزات:', error);
            return [];
        }
    }

    getDoctors() {
        try {
            const data = localStorage.getItem('clinic management _doctors');
            return data ? JSON.parse(data) : [];
        } catch (error) {
            console.error('❌ خطأ في قراءة الأطباء:', error);
            return [];
        }
    }

    getPatients() {
        try {
            const data = localStorage.getItem('clinic management _patients');
            return data ? JSON.parse(data) : [];
        } catch (error) {
            console.error('❌ خطأ في قراءة المرضى:', error);
            return [];
        }
    }

    getClinics() {
        try {
            const data = localStorage.getItem('clinic management _clinics');
            return data ? JSON.parse(data) : [];
        } catch (error) {
            console.error('❌ خطأ في قراءة العيادات:', error);
            return [];
        }
    }

    // 💾 دوال حفظ البيانات
    saveAppointments(appointments) {
        try {
            localStorage.setItem('clinic management _appointments', JSON.stringify(appointments));
            this.triggerEvent('appointmentsUpdated', appointments);
            console.log('💾 تم حفظ الحجوزات:', appointments.length);
            return true;
        } catch (error) {
            console.error('❌ خطأ في حفظ الحجوزات:', error);
            return false;
        }
    }

    saveDoctors(doctors) {
        try {
            localStorage.setItem('clinic management _doctors', JSON.stringify(doctors));
            this.triggerEvent('doctorsUpdated', doctors);
            console.log('💾 تم حفظ الأطباء:', doctors.length);
            return true;
        } catch (error) {
            console.error('❌ خطأ في حفظ الأطباء:', error);
            return false;
        }
    }

    savePatients(patients) {
        try {
            localStorage.setItem('clinic management _patients', JSON.stringify(patients));
            this.triggerEvent('patientsUpdated', patients);
            console.log('💾 تم حفظ المرضى:', patients.length);
            return true;
        } catch (error) {
            console.error('❌ خطأ في حفظ المرضى:', error);
            return false;
        }
    }

    // ➕ دوال إضافة بيانات جديدة
    addAppointment(appointmentData) {
        const appointments = this.getAppointments();
        
        // إنشاء ID فريد
        const year = new Date().getFullYear();
        const nextNumber = appointments.length + 1001;
        const appointmentId = `APT-${year}-${nextNumber}`;
        
        const newAppointment = {
            id: appointmentId,
            appointmentNumber: appointmentId,
            ...appointmentData,
            status: appointmentData.status || 'confirmed',
            statusText: this.getStatusText(appointmentData.status || 'confirmed'),
            createdAt: new Date().toISOString(),
            fees: appointmentData.fees || 165,
            paid: appointmentData.paid || false
        };
        
        appointments.push(newAppointment);
        this.saveAppointments(appointments);
        
        console.log('✅ تم إضافة حجز جديد:', newAppointment);
        return newAppointment;
    }

    addDoctor(doctorData) {
        const doctors = this.getDoctors();
        
        // إنشاء ID فريد
        const nextNumber = doctors.length + 1001;
        const doctorId = `D-${nextNumber}`;
        
        const newDoctor = {
            id: doctorId,
            ...doctorData,
            appointments: 0,
            status: 'active',
            joinedDate: new Date().toISOString().split('T')[0]
        };
        
        doctors.push(newDoctor);
        this.saveDoctors(doctors);
        
        console.log('✅ تم إضافة طبيب جديد:', newDoctor);
        return newDoctor;
    }

    addPatient(patientData) {
        const patients = this.getPatients();
        
        // إنشاء ID فريد
        const nextNumber = patients.length + 1001;
        const patientId = `P-${nextNumber}`;
        
        const newPatient = {
            id: patientId,
            ...patientData,
            createdAt: new Date().toISOString()
        };
        
        patients.push(newPatient);
        this.savePatients(patients);
        
        console.log('✅ تم إضافة مريض جديد:', newPatient);
        return newPatient;
    }

    // 🔄 دوال التحديث
    updateAppointment(appointmentId, updatedData) {
        const appointments = this.getAppointments();
        const index = appointments.findIndex(apt => apt.id === appointmentId);
        
        if (index !== -1) {
            appointments[index] = { ...appointments[index], ...updatedData };
            this.saveAppointments(appointments);
            console.log('🔄 تم تحديث الحجز:', appointmentId);
            return true;
        }
        
        console.error('❌ الحجز غير موجود:', appointmentId);
        return false;
    }

    // 🗑️ دوال الحذف
    deleteAppointment(appointmentId) {
        const appointments = this.getAppointments();
        const filtered = appointments.filter(apt => apt.id !== appointmentId);
        this.saveAppointments(filtered);
        console.log('🗑️ تم حذف الحجز:', appointmentId);
        return true;
    }

    // 🔍 دوال البحث والفلترة
    getAppointmentsByDate(date) {
        const appointments = this.getAppointments();
        return appointments.filter(apt => apt.date === date);
    }

    getAppointmentsByDoctor(doctorId) {
        const appointments = this.getAppointments();
        return appointments.filter(apt => apt.doctorId === doctorId);
    }

    getAppointmentsByPatient(patientId) {
        const appointments = this.getAppointments();
        return appointments.filter(apt => apt.patientId === patientId);
    }

    getDoctorsByClinic(clinicName) {
        const doctors = this.getDoctors();
        return doctors.filter(doctor => 
            doctor.clinic && doctor.clinic.includes(clinicName)
        );
    }

    // 📈 دوال الإحصائيات
    getStats() {
        const appointments = this.getAppointments();
        const doctors = this.getDoctors();
        const patients = this.getPatients();
        const today = new Date().toISOString().split('T')[0];
        const now = new Date();
        const weekAgo = new Date(now);
        weekAgo.setDate(weekAgo.getDate() - 7);
        
        const todayAppointments = appointments.filter(apt => 
            apt.date === today && apt.status !== 'cancelled'
        ).length;
        
        const weekAppointments = appointments.filter(apt => {
            const aptDate = new Date(apt.date);
            return aptDate >= weekAgo && aptDate <= now && apt.status !== 'cancelled';
        }).length;
        
        const pendingAppointments = appointments.filter(apt => 
            apt.status === 'pending'
        ).length;
        
        const completedAppointments = appointments.filter(apt => 
            apt.status === 'completed'
        ).length;
        
        const monthlyRevenue = appointments
            .filter(apt => {
                if (!apt.date || apt.status === 'cancelled' || !apt.paid) return false;
                const aptDate = new Date(apt.date);
                const now = new Date();
                return aptDate.getMonth() === now.getMonth() && 
                       aptDate.getFullYear() === now.getFullYear();
            })
            .reduce((total, apt) => total + (apt.fees || 0), 0);
        
        const attendanceRate = appointments.length > 0 ? 
            Math.round((completedAppointments / appointments.length) * 100) : 0;
        
        return {
            totalAppointments: appointments.length,
            totalDoctors: doctors.length,
            totalPatients: patients.length,
            todayAppointments,
            weekAppointments,
            pendingAppointments,
            completedAppointments,
            monthlyRevenue,
            attendanceRate
        };
    }

    // 🛠️ دوال مساعدة
    getStatusText(status) {
        const texts = {
            'confirmed': 'مؤكد',
            'pending': 'قيد الانتظار',
            'cancelled': 'ملغي',
            'completed': 'مكتمل'
        };
        return texts[status] || 'قيد الانتظار';
    }

    getArabicDay(dayIndex) {
        const days = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
        return days[dayIndex];
    }

    triggerEvent(eventName, data) {
        // إرسال حدث مخصص
        window.dispatchEvent(new CustomEvent(eventName, { detail: data }));
        
        // إرسال حدث storage للصفحات الأخرى
        window.dispatchEvent(new StorageEvent('storage', {
            key: `clinic management _${eventName.replace('Updated', '').toLowerCase()}`,
            newValue: JSON.stringify(data)
        }));
    }

    // 🔧 أدوات التصحيح
    debugStorage() {
        console.group('🔍 حالة التخزين الحالية:');
        console.log('📅 الحجوزات:', this.getAppointments());
        console.log('👨‍⚕️ الأطباء:', this.getDoctors());
        console.log('👤 المرضى:', this.getPatients());
        console.log('🏥 العيادات:', this.getClinics());
        console.log('📊 الإحصائيات:', this.getStats());
        console.groupEnd();
    }

    clearAllData() {
        if (confirm('هل تريد حذف جميع البيانات؟ هذا الإجراء لا يمكن التراجع عنه.')) {
            localStorage.removeItem('clinic management _appointments');
            localStorage.removeItem('clinic management _doctors');
            localStorage.removeItem('clinic management _patients');
            localStorage.removeItem('clinic management _clinics');
            this.initStorage();
            alert('تم حذف جميع البيانات وإعادة التهيئة');
            location.reload();
        }
    }
}

// إنشاء نسخة عامة من DataManager
window.DataManager = DataManager;
window.dataManager = new DataManager();